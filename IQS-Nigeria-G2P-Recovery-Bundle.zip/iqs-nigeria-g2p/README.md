# IQS Nigeria G2P sandbox

Installation reference, IQS customizations, household registration integration,
operations guides and submitted UX delivery documents for the Nigeria project.

## Start here

1. Read `docs/guides/IQS-Nigeria-OpenG2P-Installation-Guide.docx`.
2. Extract `installation/IQS-Nigeria-Installation-Kit.zip` to `C:\IQS-Install` on Windows, then copy the kit contents to `/opt/openg2p-install` inside Ubuntu as described in the guide.
3. Overlay this repository's `lab/` contents into `/opt/openg2p-install/lab` before executing the guided Linux stages. On Windows also copy `lab/` into `C:\IQS-Install\IQS-Installation-Kit\lab` for the Windows launchers. The repository contains updates made after the original installation kit.
4. Follow the manual's stages and checkpoints. Do not run every script in alphabetical order: several are diagnostic or reference scripts tied to original fixture IDs.
5. Generate new passwords, certificates, OIDC client secrets and tunnel credentials on the destination.
6. Configure public access with the Cloudflare setup guide only after local verification. Recreate the tunnel for the destination; do not reuse a tunnel credential from GitHub.
7. Read `docs/REINSTALL.md` for the registration integration and validation boundaries.

## Contents

| Folder | Purpose |
| --- | --- |
| installation | Original portable kit with pinned charts, dependencies and retained patches |
| lab | Adapted project scripts, registration source, templates and branding |
| inventory | Recorded image digests, chart releases, source commits and synthetic fixtures |
| docs/guides | Installation, operations and Cloudflare Word guides |
| docs/ux | Illustrated UX improvement recommendations |
| docs/scope | Submitted SOW, SOP and delivery framework documents |

## Reproduction boundaries

The original Windows WSL2 environment and registration integration have been exercised. A clean-machine replay and the native Ubuntu adaptation have not been executed. This repository is a staged installation reference, not a verified unattended installer. Internet access is required for infrastructure tools and container images.

Git preserves code and documentation. It does not preserve running databases, persistent volumes, identities, approved applications or external DNS configuration. Use a separate encrypted backup for runtime data and secrets if an exact state migration is needed. See the operating guide and `lab/Backup-Lab.ps1`.

PBMS 3 and the legacy beneficiary portal use different programme models. The newer registration integration and household adapter connect their approved sandbox journeys; unrelated legacy edits and all seeded programmes are not automatically synchronized. No live payment, Nigerian identity, SMS or email service is configured.

## Upstream components

The kit includes third-party charts and dependencies with their retained notices. The upstream software remains subject to its own licenses. Image digests and source commit references are in `inventory/installed-versions.json`. No broad license grant is implied for IQS project documents or assets.

## Integrity

`MANIFEST.sha256.json` records the packaged file hashes. Keep credentials, Cloudflare tokens, kubeconfigs, private keys, database backups and credential reference documents outside Git, including private repositories.
