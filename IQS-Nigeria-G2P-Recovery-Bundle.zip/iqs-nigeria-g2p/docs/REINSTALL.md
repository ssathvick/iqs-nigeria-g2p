# Reinstall on another machine

## Base platform

Use the installation Word guide and its portable kit for the exact staged commands, requirements, chart versions and retained repairs. The deployment namespace is `nigeria`. The Linux source path in the copied scripts is `/opt/openg2p-install/lab`; the runtime path is `/opt/openg2p-lab`. Read each script before execution, particularly tests with fixture IDs. Initial local domains must match the manual before adapting external domains.

## Newer registration integration

After the base platform works:

1. Configure the public domain, origin Nginx site and Cloudflare connector following the Cloudflare guide. Public-domain scripts currently target `nigeriag2p.com`. A different domain needs a reviewed change across scripts, redirects, OIDC, origin routes and portal URLs.
2. Ensure the portal compatibility backend is initialized and the household adapter is available. Review `lab/install-household-adapter.py` and `lab/connect-pbms-bridge.py` in relation to the installed models.
3. Install the Python dependencies in the registration virtual environment:

```bash
sudo python3 -m venv /opt/openg2p-lab/registration-venv
sudo /opt/openg2p-lab/registration-venv/bin/pip install -r /opt/openg2p-install/lab/registration-requirements.txt
```

4. Review and execute the integration installer using a Python environment with requests and PyYAML installed. It requires live Keycloak, Kubernetes, Nginx, the platform databases, the runtime credentials file and the local CA established by the preceding installation stages:

```bash
sudo python3 /opt/openg2p-install/lab/install-registration-integration.py
sudo systemctl status iqs-registration.service iqs-registration-sync.timer --no-pager
```

The installer creates new OIDC client credentials locally. It enables beneficiary self-registration and assigns the reviewer role to the existing sandbox staff administrator. It does not establish production separation of duties.

5. Follow `lab/Registration-Integration-Operations.txt`. Register a fictional household, approve it, confirm linked records, apply to an integrated programme, run native PBMS eligibility and confirm enrollment. Also test an ineligible household, permission denial, duplicate submission and retry after a transient failure.

6. The public startup BAT assumes the configured connector and registration units exist. Its normal use is startup after installation, not initial installation.

## Backup versus clean installation

A clean installation generates fresh accounts and empty operational state, then optionally seeds fictional fixtures. An exact migration additionally requires database/volume backups, registration SQLite state, relevant private keys and secure configuration transfer. These belong in encrypted backup storage, not in GitHub.

## Acceptance

Verify workload readiness, every configured application URL, correct role access, registry synchronization, eligible and ineligible enrollment cases, restart persistence, HTTPS trust and Cloudflare reconnect. Record the destination versions and results. Never infer production readiness from the presence of the source code or from the original machine's test results.
