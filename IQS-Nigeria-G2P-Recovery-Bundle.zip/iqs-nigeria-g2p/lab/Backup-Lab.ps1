wsl -d Ubuntu-22.04 -u root -- python3 /opt/openg2p-install/lab/backup-lab.py
if ($LASTEXITCODE -ne 0) { throw 'OpenG2P backup failed.' }
