import sys
sys.path.insert(0,'/opt/openg2p-install/lab');from labdb import query
print(query('postgres','SELECT datname,count(*) FROM pg_stat_activity GROUP BY datname;'))
print(query('postgres','SELECT rolname FROM pg_roles WHERE rolcanlogin;'))
