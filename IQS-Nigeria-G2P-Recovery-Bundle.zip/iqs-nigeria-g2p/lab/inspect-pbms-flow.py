exec(open('/opt/openg2p-install/lab/test-pbms-enrollment.py').read().split('program=')[0])
for model in ['g2p.beneficiary.list','g2p.disbursement.cycle']:
 fields=call(model,'fields_get',[],{'attributes':['type','selection','required']})
 print(model,fields)
 print(call(model,'search_read',[[]],{'limit':3}))
