exec(open('/opt/openg2p-install/lab/bootstrap-portal.py').read().split("call('ir.module.module','update_list'")[0])
print(call('formio.version','fields_get',[],{'attributes':['type','required','selection','relation']}))
print(call('formio.version','search_read',[[]]))
