from pathlib import Path
import json,csv,re,subprocess,concurrent.futures,collections,html,hashlib,zipfile
from PIL import Image,ImageDraw,ImageFont
from build_designs import ROOT,PROJECT,CLI,MODULES,safe

MASTER='NigeriaG2P-Master-UX-UI-Prototype'
native=json.loads((ROOT/'qa'/f'{MASTER}-native.json').read_text(encoding='utf-8'))
roundtrip=json.loads((ROOT/'qa'/f'{MASTER}-roundtrip.json').read_text(encoding='utf-8'))
nodes=native['nodes'];rnodes=roundtrip['nodes']
spec={s['id']:(m,s) for m in MODULES for s in m['screens']}

def root_frame(n,data):
 while n.get('parent') is not None:
  p=data.get(str(n['parent']),{})
  if p.get('type')=='page':return n if n.get('type')=='frame' else None
  n=p
 return None

def semantic(data):
 nd=data['nodes'];edges=[]
 for n in nd.values():
  f=root_frame(n,nd)
  if not f:continue
  for interaction in n.get('interactions',[]):
   for a in interaction.get('actions',[]):
    if a.get('type')=='navigate':
     dest=nd.get(str(a.get('dest')),{});edges.append((f['name'],n.get('name'),dest.get('name')))
 return collections.Counter(edges)

assert semantic(native)==semantic(roundtrip),'Prototype destination changed during FigCraft export/import'
issues=[];frame_index={n['name'].split(' / ')[0]:n for n in nodes.values() if n.get('type')=='frame' and n['name'].startswith('NG2P-')}
for n in nodes.values():
 p=nodes.get(str(n.get('parent','')),{})
 if p.get('type')=='frame' and p.get('name','').startswith('NG2P-'):
  a=n.get('transform',[1,0,0,1,0,0]);x,y=a[4:6]
  if x < -1 or y < -1 or x+n.get('width',0)>p['width']+2 or y+n.get('height',0)>p['height']+2:issues.append({'node':n['id'],'frame':p['name'],'issue':'outside frame'})

def export_module(m):
 stem='NG2P-'+m['code']+'-'+safe(m['name'])
 result=subprocess.run([str(CLI),'export',str(ROOT/'designs'/f'{stem}.figcraft'),'-o',str(ROOT/'previews'/m['code']),'--page',m['code']+' '+m['name'],'--scale','0.75'],capture_output=True,text=True,encoding='utf-8')
 if result.returncode:raise RuntimeError(result.stderr)
 return m['code']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 print('Rendered '+', '.join(pool.map(export_module,MODULES)),flush=True)
for code,name in [('START','NG2P-START-001 / Service map / D1440'),('DS','NG2P-DS-001 / Foundations / D1440')]:
 result=subprocess.run([str(CLI),'export',str(ROOT/'designs'/f'{MASTER}.figcraft'),'-o',str(ROOT/'previews'/f'{code}.png'),'--node',str(next(n['id'] for n in nodes.values() if n['name']==name)),'--scale','0.75'],capture_output=True,text=True)
 assert result.returncode==0,result.stderr

# Browser companion uses the same screens and hotspot destinations as the native
# document; it is supplementary, never used as the purported .fig deliverable.
preview={}
for p in (ROOT/'previews').rglob('*.png'):
 match=re.match(r'(NG2P-[A-Z]+-(?:\d{3}|INDEX))',p.name)
 if match:preview[match[1]]=p.relative_to(ROOT).as_posix()
preview['NG2P-START-001']='previews/START.png';preview['NG2P-DS-001']='previews/DS.png'
screens={};interactions=[]
for key,f in frame_index.items():
 if key not in preview:continue
 m,s=spec.get(key,({},{}));role=m.get('role','Design reviewer')
 # Retrieve the screen-specific review/publisher role from the visible layer.
 for child in f.get('children',[]):
  tx=nodes[str(child)].get('characters','')
  if tx.startswith('ROLE\n'):role=tx.split('\n',1)[1]
 screens[key]={'name':f['name'],'width':f['width'],'height':f['height'],'image':preview[key],'module':m.get('code',key.split('-')[1]),'role':role,'source':m.get('source','Design foundations / service map'),'evidence':m.get('evidence','Design documentation'),'note':m.get('note',''), 'hotspots':[]}
 for n in nodes.values():
  if n.get('parent')!=f['id'] or not n.get('name','').startswith('Button / '):continue
  for it in n.get('interactions',[]):
   for a in it.get('actions',[]):
    dest=nodes.get(str(a.get('dest')),{});destkey=dest.get('name','').split(' / ')[0]
    if a.get('type')=='navigate':
     if destkey not in frame_index:issues.append({'node':n['id'],'issue':'missing destination'})
     t=n.get('transform',[1,0,0,1,0,0]);label=n['name'].split('Button / ',1)[1]
     hotspot={'label':label,'x':t[4],'y':t[5],'width':n['width'],'height':n['height'],'target':destkey}
     screens[key]['hotspots'].append(hotspot);interactions.append({'from':key,'action':label,'to':destkey,'trigger':'onClick','transition':'dissolve / 160 ms'})

adj=collections.defaultdict(set)
for edge in interactions:adj[edge['from']].add(edge['to'])
reachable=set();pending=['NG2P-START-001']
while pending:
 x=pending.pop()
 if x in reachable:continue
 reachable.add(x);pending.extend(adj[x]-reachable)
assert set(spec)<=reachable,'Unreachable task screens: '+str(set(spec)-reachable)
assert not issues,issues
assert len(spec)==240

with (ROOT/'handover'/'Screen-Register.csv').open('w',newline='',encoding='utf-8-sig') as f:
 fields=['Screen ID','Module','Task / state','Viewport','Responsible role','Layout','Evidence classification','Source file','Reference route','Review note']
 writer=csv.writer(f);writer.writerow(fields)
 for m in MODULES:
  for s in m['screens']:writer.writerow([s['id'],m['name'],s['title'],s['viewport'],screens[s['id']]['role'],s['kind'],m['evidence'],m['source'],m['route'],m['note']])
with (ROOT/'handover'/'Interaction-Register.csv').open('w',newline='',encoding='utf-8-sig') as f:
 writer=csv.DictWriter(f,fieldnames=['from','action','to','trigger','transition']);writer.writeheader();writer.writerows(interactions)

source_manifest=[]
for source in sorted(set(m['source'] for m in MODULES)):
 p=PROJECT/source
 source_manifest.append({'path':source,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'purpose':'Read-only design reference; no live system verification'})
(ROOT/'handover'/'Source-Manifest.json').write_text(json.dumps(source_manifest,indent=2),encoding='utf-8')

FONT=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',17)
for m in MODULES:
 items=m['screens'];cols=4 if not m['mobile'] else 5;tw=360 if not m['mobile'] else 190;th=330 if not m['mobile'] else 450
 sheet=Image.new('RGB',(cols*tw,80+((len(items)+cols-1)//cols)*th),'#E4EBE8');draw=ImageDraw.Draw(sheet)
 draw.text((18,15),m['code']+' · '+m['name']+' · '+str(len(items))+' screen states',font=FONT,fill='#143D35')
 for i,s in enumerate(items):
  im=Image.open(ROOT/preview[s['id']]);im.thumbnail((tw-16,th-60));x=(i%cols)*tw+8;y=70+(i//cols)*th
  sheet.paste(im,(x,y));draw.text((x,y+th-49),s['id'],font=FONT,fill='#143D35')
 sheet.save(ROOT/'qa'/f'contact-{m["code"]}.jpg',quality=88)

checks=[]
for p in (ROOT/'qa').glob('*-validation.json'):
 check=json.loads(p.read_text());assert check['native']==check['figcraft_reopen_of_fig'],p.name;checks.append(check)
fig_headers={p.name:p.read_bytes()[:8].hex() for p in (ROOT/'designs').glob('*.fig')}
validation={'built_on':'3 November 2026','generator':'FigCraft CLI 0.7.0 (installed)','module_count':len(MODULES),'task_state_screens':len(spec),'master_pages':sum(n['type']=='page' for n in nodes.values()),'prototype_flow_starts':sum(len(n.get('flows',[])) for n in nodes.values()),'unique_clickable_controls':len(interactions),'all_task_screens_reachable':True,'prototype_destinations_preserved_on_figcraft_reimport':True,'outside_frame_nodes':len(issues),'all_27_files_preserve_structure_on_figcraft_reimport':len(checks)==27,'figma_application_import_and_playback_verified':False,'limitations':['FigCraft .fig export is experimental. Independent Figma import, font fidelity and prototype playback remain to be verified.','Prototype is click-through. Form editing, uploads, authentication and API outcomes are design states, not a working backend.','240 screens are the prepared design baseline. Uninspected upstream native interfaces are not an audited exhaustive screen inventory.','No public or staff permissions, applications or data were changed.'],'fig_file_headers':fig_headers}
(ROOT/'handover'/'Validation-Report.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')

readme=f'''# NSIPA NigeriaG2P UX/UI and interactive design baseline

Prepared by Sathvick Infotech Private Limited · 3 November 2026 · v2.0

## Version 2 identity update

NSIPA Shared Progress replaces the previous platform wordmark across all 240 task/state screens. Logos are editable native vector layers. Green #006B45, gold #D5A63C and deep green #123E31 match the deployed identity. Editable AI/SVG/PSD masters are in `assets/NSIPA-Identity`. Stable screen IDs and workflow destinations are retained. This release updates branding; the existing workflow evidence classifications remain unchanged.

## Start here

Open `designs/{MASTER}.figcraft` in FigCraft for the editable master.
Use its Present/Play control and choose **00 · NSIPA service map**.
Select a service, then use its task actions. **Journey index** exposes every named state.
Each module also has its own prototype starting point. **All services / Service map** returns to the master navigation.

For Figma, import `designs/{MASTER}.fig` from Figma's file browser. Inspect text, components, the Prototype panel and flow starting points, then test the example journeys below. Figma import/playback has **not** been independently verified here. These are actual FigCraft-generated `.fig` exports, not renamed images or SVGs. Their layer trees and prototype destinations were checked by reopening them in FigCraft; that is not equivalent to validating them in Figma.

`designs/NG2P-*.figcraft` and `.fig` are the 26 application-area files for smaller handovers. Each contains its own service entry, foundations, screens and task index. Cross-application transitions are included in the master only. The standalone files return to their own local service map.

Open `Prototype-Preview.html` to inspect an offline browser companion using the same screen images and clickable destinations. It is supplementary; the editable design deliverables are under `designs/`.

## Contents

- **240 task/state screens** across **26 application areas**.
- **28 master pages**, including the service map and foundations; **27 prototype flow starts**.
- **8 reusable native components**, linked button instances, semantic colour styles and typography styles.
- Desktop 1440 × 1040 layouts; mobile 390 × 844 field and public-portal layouts.
- **{len(interactions)} clickable controls** in the master. Text and button backgrounds share destinations in the native files; raw interaction counts therefore exceed the count of visible controls.
- `handover/Screen-Register.csv`: every designed screen, responsible role, route, source and caveat.
- `handover/Interaction-Register.csv`: named source/action/destination mapping.
- `handover/Source-Manifest.json`: hashes of local files used as reference.
- `handover/Validation-Report.json`: exact checks and remaining limitations.
- `previews/`: all application screen previews. `source/`: editable command scripts and structured screen specification.

## Screen naming

`NG2P-{{MODULE}}-{{###}} / {{Task}} / {{Viewport}} / {{State}}`

Example: `NG2P-MBR-004 / Correct household details / D1440 / correct-household-details`.

Frame IDs are stable within this design baseline. D1440 means desktop; M390 means mobile.
Each application page contains task frames in reading order and a separate journey index.
Components use `NG2P/Button/Primary`, `NG2P/Input/Default` and related semantic names.

## Application coverage

'''+ '\n'.join(f'- **{m["code"]} — {m["name"]}:** {len(m["screens"])} screens; {m["evidence"]}.' for m in MODULES)+'''

## Review these journeys

1. MBR: work queue → household → correction → submit → independent checklist → approval confirmation → synchronisation. Branch into validation errors, return with reason and sync conflict.
2. KMS: library → search → guidance → feedback; editorial queue → draft → optional AI suggestion → save → independent review → publication confirmation → version history → archive → restore. Include reviewer return and version conflict.
3. PBMS/Bridge: approved NSR import → eligibility → enrolment → benefit calculation → batch review; dispatch acceptance → bank response → statement → reconciliation, mismatch, callback retry, reversal and duplicate protection. Only fictional local Example Bank evidence is represented.
4. Field: assignment → capture → device queue → synchronisation → conflict or success, with mock mismatch and expired certification states.
5. Portal/GRM: programme discovery → details → existing support/application prototype → validation/submission/tracking; grievance → acknowledgement/escalation/resolution.
6. Analytics: overview → filters → current operations / knowledge usage → source freshness → stale/failed source → aggregate export or denied role.

## What this baseline represents

The designs are a consistent source-led redesign and a reviewable interaction baseline, not a pixel-perfect capture of every installed product. Local templates, React persona code, the service catalogue and project operational notes were read. No live sign-ins, private native screens or current production deployment were audited during this build.

Private SPAR/Bridge interfaces and uninspected native administration screens are explicitly **proposed reference designs**. Supporting-service screens are overview references, not exhaustive replacements for MinIO, Kafka, Keycloak, ODK, Superset or other upstream consoles. API-only services do not imply an existing UI. Consequently, this package must not be described as a verified complete inventory of every upstream screen. Reconcile the register with Ooru before final acceptance.

The interactive prototypes use click navigation and state transitions. Text fields, uploads, searches, role changes, approvals, exports and backend outcomes are illustrated; this is not a functional application or permission test. Fields and vector/text layers are editable in the design document. The eight components and styles provide a starter design system, not a full production component library. Fixed desktop/mobile frames are provided, not every responsive breakpoint or a full translation set.

## Required project distinctions

- Registration/application screens are prototypes; the core Phase-1 CCT flow starts from approved NSR data.
- Independent verification and publishing roles remain separate from authors/makers.
- A PBMS process marked complete or a Bridge-accepted instruction is not confirmed production settlement.
- The portal backend is separate and does not automatically join PBMS 3 applications.
- Field identity/GPS, intake channels, CCT rules and agent certification are sandbox demonstrations pending policy/device approval.
- Analytics filter scopes, UTC timestamps, stale-source states and export permissions must remain explicit. Opens are not unique readers; contextual-help usage and settled-payment analytics are not claimed.
- Public language options are English, Hausa, Yoruba and Igbo; the design labels and sample content are English. Translations and accessibility testing are pending.
- No scope, price, hours, UAT acceptance, production readiness or commercial variation is approved by this package. The earlier proposal and KMS quantity baseline are unchanged.

## Acceptance and remaining work

1. Import the master `.fig` in Figma and verify layer editability, fonts, components, links and all 27 starting points. FigCraft warns that `.fig` export is experimental. Plugin metadata is omitted from this export, so keep the CSV/JSON registers and `.figcraft` source with the handover.
2. Ooru should confirm private native screens, actual roles, canonical workflows, error codes and permitted channels against the register.
3. Government/PMO should approve SOPs, field/consent wording, eligibility, payment authority, grievance SLAs and translations.
4. Reconcile any missing upstream states and breakpoints; review the proposed redesign against the installed products rather than assuming exact parity.
5. Test keyboard use, screen-reader names, contrast, focus order, mobile devices and real integration behaviours in implementation.

## Validation performed

All 27 `.fig` exports reopened through FigCraft's importer with matching structural counts. The master retained semantic source/action/destination mappings. All 240 task/state screens are reachable from its service map through actions and task indexes. No direct screen children extend outside their frames. Screen previews were rendered by the installed FigCraft engine. This does not prove Figma compatibility or live system behaviour.

## References

- FigCraft CLI: https://github.com/storytold/figcraft/blob/main/docs/cli.md
- FigCraft export compatibility: https://github.com/storytold/figcraft/blob/main/docs/file-format-parity.md
- Figma import guide: https://help.figma.com/hc/en-us/articles/360040027794-Guide-to-imports-in-Figma-Design
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')

data={'screens':screens,'modules':[{'code':m['code'],'name':m['name'],'start':m['screens'][0]['id']} for m in MODULES]}
page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NSIPA v2 design prototype preview</title><style>
*{box-sizing:border-box}body{margin:0;font:14px 'Segoe UI',Arial,sans-serif;background:#e4ebe8;color:#183d35}header{position:sticky;top:0;z-index:2;background:#143d35;color:white;padding:14px 22px;display:flex;gap:16px;align-items:center;flex-wrap:wrap}header strong{font-size:19px}button,select{font:inherit;padding:9px;border-radius:6px;border:1px solid #b6c8c0;background:white;color:#143d35}select{max-width:330px}main{padding:22px}#caption{margin:0 auto 16px;max-width:1440px}#stage{position:relative;margin:auto;box-shadow:0 8px 35px #143d3520}#stage img{display:block;width:100%;height:auto}#stage button{position:absolute;padding:0;background:transparent;border:0;border-radius:6px;cursor:pointer}#stage button:hover,#stage button:focus-visible{background:#c993302e;outline:3px solid #c99330}#stage.hints button{outline:2px dashed #c99330}details{max-width:1440px;margin:22px auto;line-height:1.7}footer{padding:22px;text-align:center}a{color:#07634e}</style>
<header><img src="assets/nsipa-wordmark.svg" alt="NSIPA" style="width:112px;height:30px;object-fit:contain"><strong>Design review v2</strong><button id="home">Service map</button><button id="back">Back</button><select id="module" aria-label="Application area"></select><select id="screen" aria-label="Task or screen state"></select><button id="hints">Show clickable areas</button></header>
<main><div id="caption"></div><div id="stage"></div><details><summary>Source, scope and remaining verification</summary><p id="note"></p><p>This browser preview is supplementary. Open the editable .figcraft or .fig files in the designs folder. Native Figma import and prototype playback remain to be verified. All examples are fictional.</p></details></main><footer>Prepared by Sathvick Infotech Private Limited · 3 November 2026 · 240 source-led and proposed screen states</footer>
<script>const DATA=__DATA__;const stage=document.querySelector('#stage'),mod=document.querySelector('#module'),sel=document.querySelector('#screen');let trail=[],current='';
for(const m of DATA.modules){let o=document.createElement('option');o.value=m.code;o.textContent=m.code+' · '+m.name;mod.append(o)}
function go(id,record=true){let s=DATA.screens[id];if(!s)return;if(record&&current)trail.push(current);current=id;location.hash=id;stage.replaceChildren();stage.style.maxWidth=s.width+'px';let im=document.createElement('img');im.src=s.image;im.alt=s.name;stage.append(im);for(let h of s.hotspots){let b=document.createElement('button');b.title=h.label;b.setAttribute('aria-label',h.label);Object.assign(b.style,{left:h.x/s.width*100+'%',top:h.y/s.height*100+'%',width:h.width/s.width*100+'%',height:h.height/s.height*100+'%'});b.onclick=()=>go(h.target);stage.append(b)}document.querySelector('#caption').textContent=s.name+' · '+s.role;document.querySelector('#note').textContent=s.evidence+'. Reference: '+s.source+'. '+s.note;mod.value=s.module;sel.replaceChildren();for(let [key,v] of Object.entries(DATA.screens)){if(v.module!==s.module)continue;let o=document.createElement('option');o.value=key;o.textContent=key+' · '+v.name.split(' / ')[1];sel.append(o)}sel.value=id;window.scrollTo(0,0)}
mod.onchange=()=>go(DATA.modules.find(m=>m.code===mod.value).start);sel.onchange=()=>go(sel.value);document.querySelector('#home').onclick=()=>go('NG2P-START-001');document.querySelector('#back').onclick=()=>{let id=trail.pop();if(id)go(id,false)};document.querySelector('#hints').onclick=()=>stage.classList.toggle('hints');window.addEventListener('hashchange',()=>{const next=decodeURIComponent(location.hash.slice(1));if(next&&next!==current)go(next,false)});go(decodeURIComponent(location.hash.slice(1))||'NG2P-START-001',false);
</script></html>'''
(ROOT/'Prototype-Preview.html').write_text(page.replace('__DATA__',json.dumps(data,ensure_ascii=False).replace('</','<\\/')),encoding='utf-8')
print(json.dumps(validation,indent=2)[:1700],flush=True)
