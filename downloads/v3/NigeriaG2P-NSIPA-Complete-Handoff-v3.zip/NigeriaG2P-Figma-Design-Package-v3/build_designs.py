from pathlib import Path
import json, csv, subprocess, hashlib, re, time, collections, zipfile

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent.parent
CLI=Path(r'C:\Program Files\FigCraft\figcraft-cli.exe')
for folder in ['designs','source','previews','qa','handover']:(ROOT/folder).mkdir(exist_ok=True)

# Source-led design specification. Native consoles and uninspected private screens
# are explicitly proposed reference designs, never passed off as audited replicas.
MODULES=[]
def module(code,name,role,evidence,source,route,fields,rows,items,mobile=False,note=''):
    screens=[]
    for i,item in enumerate(items.split('|')):
        title,kind=item.split('~')
        screens.append(dict(id=f'NG2P-{code}-{i+1:03}',title=title,kind=kind,viewport='M390' if mobile else 'D1440',state=re.sub('[^a-z0-9]+','-',title.lower()).strip('-')))
    MODULES.append(dict(code=code,name=name,role=role,evidence=evidence,source=source,route=route,fields=fields.split('|'),rows=[x.split(';') for x in rows.split('|')],screens=screens,mobile=mobile,note=note))

module('AUTH','Identity and access','Staff / beneficiary','Proposed shared UX','openg2p-lab/registration_app.py','/registration/login','Email or staff ID|Password|Organisation|Verification code','Staff workspace;Staff SSO;Available|Beneficiary portal;Separate sign-in;Available|Session;One hour demo;Expires',
 'Choose sign-in destination~cards|Staff sign-in~form|Sign-in validation~error|Access denied~error|Session expired~warning|Signed out~success|Beneficiary sign-in~form',note='Separate staff and beneficiary sessions. This prototype does not authenticate or request real credentials.')
module('HOME','Service and persona workspaces','Registration officer','Source-led redesign','openg2p-lab/persona-ui/src/catalogue.js','/registration/workspace','Search services|Persona|Service group|Access scope','Registration;12 synthetic households;Review needed|Knowledge;Published guidance;Available|Analytics;Aggregate workspace;Available',
 'Service catalogue~cards|Registration officer workspace~dashboard|Verification officer workspace~dashboard|Programme supervisor workspace~dashboard|Citizen support workspace~dashboard|No assigned services~empty')
module('MBR','Beneficiary repository','Registration officer','Source-led redesign','openg2p-lab/persona-ui/src/main.jsx','/registration/workspace','Household name|State / FCT|LGA|Community|Monthly income (NGN)|Correction reason','DEMO-HH-001;Kano / Dala;Correction required|DEMO-HH-002;Lagos / Ikeja;Awaiting review|DEMO-HH-003;FCT / AMAC;Approved',
 'Household work queue~list|Household overview~detail|Members and identity~detail|Correct household details~form|Correction validation errors~error|Unsaved changes confirmation~confirm|Correction submitted~success|Independent verification checklist~checklist|Return reason~form|Returned for correction~warning|Approve registration confirmation~confirm|Registration approved~success|Registry synchronisation pending~warning|Registry synchronisation conflict~error|Registry synchronised~success|Case activity history~timeline|NSR intake prototype~form',note='New intake is a prototype. Phase-1 CCT starts with approved NSR records. Verification is independent; no real eligibility decision occurs.')
module('REG','Modern social registry','Registry officer','Native reference redesign','openg2p-lab/README.md','https://register.nigeriag2p.com/','Search individual or household|Record type|State / FCT|Change reason','DEMO-P-001;Individual;Active|DEMO-HH-001;Household;Active|DEMO-CR-001;Change request;Pending',
 'Registry overview~dashboard|Individuals directory~list|Individual profile~detail|Households directory~list|Household membership~detail|Demographic change request~form|Change request approval status~timeline|Registry empty search~empty',note='Source records describe these native functions. These are harmonised designs, not pixel-verified native screens.')
module('RADM','Social registry administration','Registry administrator','Proposed native reference','openg2p-lab/persona-ui/src/catalogue.js','https://registry.nigeriag2p.com/web','Registry record|Household member|Relationship|Change justification','Households;Membership management;Available|Individuals;Demographic records;Available|Import jobs;Validation results;Review',
 'Registry administration~dashboard|Household record~detail|Edit membership~form|Import validation report~list|Membership change recorded~success')
module('PBMS','Programme management','Programme supervisor','Source-led / proposed native UX','openg2p-lab/Phase1-Sandbox-Operations.md','https://pbms.nigeriag2p.com/web','Programme name|Benefit amount (NGN)|Approved NSR list|Cycle|Eligibility rule version|Decision reason','DEMO-CCT;6 fixture beneficiaries;Draft cycle|DEMO-HHS;NGN 25,000 benefit;Configured|DEMO-LIST;Approved NSR reference;Review',
 'Programme overview~dashboard|Programme directory~list|Programme configuration~form|Approved NSR import~upload|Eligibility preview~list|Eligibility exceptions~warning|Beneficiary list approval~checklist|Enrolment confirmed~success|Benefit calculation~detail|Disbursement batch review~list|Conditionality evidence~form|Independent conditionality verification~checklist|Release or hold decision~confirm|Conditionality held~warning|Batch instruction accepted~success',note='Fictional CCT threshold is a demonstration only. Bridge acceptance and PBMS complete do not mean bank settlement. Portal uses a separate compatible backend.')
module('AWE','Approval workflows','Verification officer','Native reference redesign','openg2p-lab/README.md','https://awe.nigeriag2p.com/','Task reference|Request type|Assignee|Decision note','DEMO-TASK-001;Demographic change;Assigned|DEMO-TASK-002;Second-stage review;Pending|DEMO-TASK-003;Callback retry;Failed',
 'Assigned approval tasks~list|Approval request detail~detail|Evidence checklist~checklist|Approve task confirmation~confirm|Return task with reason~form|Signed callback pending~warning|Callback delivered~success|Callback delivery failed~error',note='Two-stage approval and signed callback are source-described. No workflow policy is changed by the prototype.')
module('SPAR','Payment account registry','Payment operations officer','Proposed private-API UX','openg2p-lab/Phase1-Sandbox-Operations.md','https://spar.nigeriag2p.com/docs','Beneficiary reference|Bank code|Masked account reference|Account type|Update reason','DEMO-MAP-001;Bank reference •••• 0012;Linked|DEMO-MAP-002;Bank reference •••• 0024;Rejected|DEMO-MAP-003;Resolution request;Pending',
 'Account mapping overview~dashboard|Account links~list|Link payment account~form|Mapping validation failed~error|Review account update~confirm|Account linked~success|Resolve beneficiary account~form|Resolution result~detail|No eligible account~warning',note='Native SPAR UI is private. All account references here are invented and masked. Proposed UX needs Ooru/agency validation.')
module('BRG','G2P Bridge payments','Payment operations officer','Source-led / proposed private UX','openg2p-lab/Phase1-Sandbox-Operations.md','https://bridge.nigeriag2p.com/docs','Instruction reference|Programme cycle|Currency|Bank route|Statement date|Resolution note','DEMO-INS-001;NGN 25,000;Instruction accepted|DEMO-INS-002;NGN 25,000;Bank pending|DEMO-INS-003;NGN 25,000;Exception',
 'Payment operations~dashboard|Instruction batches~list|Batch detail and controls~detail|Dispatch authorisation~confirm|Dispatch accepted~success|Bank response pending~warning|Statement upload~upload|Reconciliation results~list|Mismatch investigation~detail|Retry callback confirmation~confirm|Reversal recorded~warning|Fixture bank credit confirmed~success|Duplicate statement prevented~error',note='Native UI private. Only local Example Bank fixture credit is evidenced. No production settlement, reversal authority or external rail approval is implied.')
module('FLD','Last-mile delivery','Certified field agent','Source-led demonstration','openg2p-lab/registration-ui/phase1-field.html','/registration/phase1/field','Household reference|Agent reference|Mock biometric result|Test latitude / longitude','DEMO-HH-001;Queued on device;Not synced|DEMO-HH-002;Delivery proof;Synced|DEMO-HH-003;Duplicate proof;Conflict',
 'Field assignments~list|Offline readiness~warning|Capture delivery proof~form|Mock biometric mismatch~error|Proof saved on device~success|Device queue offline~list|Synchronisation in progress~warning|Synchronisation conflict~error|Proof synchronised~success|Agent certification expired~error',mobile=True,note='Biometrics and coordinates are simulated. Offline 48-hour acceptance requires a real device duration test. Mobile application and roles need approval.')
module('PAR','Partner and agent management','Partner administrator','Source-led / proposed native UX','openg2p-lab/Phase1-Sandbox-Operations.md','https://partner-management.nigeriag2p.com/','Partner name|Organisation type|Territory|Training record|Certification decision|Revocation reason','DEMO-PART-001;Service partner;Active|DEMO-AGT-001;Field agent;Training required|DEMO-AGT-002;Field agent;Certified',
 'Partner overview~dashboard|Partner directory~list|Onboarding application~form|Partner review~checklist|Partner enabled~success|Agent directory~list|Training record~form|Agent certification~confirm|Certification granted~success|Revoke certification~confirm|Certification revoked~warning',note='Agent certification belongs to a separate demo module, not verified native partner certification functionality.')
module('CON','Consent management','Consent administrator','Proposed native reference','openg2p-lab/persona-ui/src/catalogue.js','https://consent-manager.nigeriag2p.com/','Subject reference|Purpose|Data scope|Expiry|Withdrawal reason','DEMO-CON-001;Programme support;Active|DEMO-CON-002;Partner access;Expired|DEMO-CON-003;Data sharing;Withdrawn',
 'Consent directory~list|Consent receipt~detail|Consent request~form|Consent request review~confirm|Withdraw consent~confirm|Withdrawal recorded~success|Consent expired~warning',note='Policy and citizen consent wording require agency approval; native screens were not inspected.')
module('GRM','Grievance resolution','Grievance officer','Source-led demonstration','openg2p-lab/registration-ui/phase1-grievances.html','/registration/phase1/grievances','Household reference|Intake channel|Issue category|Issue description|Resolution note|Escalation reason','DEMO-GRM-001;Payment delay;Awaiting acknowledgement|DEMO-GRM-002;Registration issue;Escalated|DEMO-GRM-003;Service complaint;Resolved',
 'Grievance work queue~list|Register grievance~form|Grievance validation error~error|Grievance registered~success|Case and deadlines~detail|Acknowledge case~confirm|Escalate case~form|Escalation recorded~warning|Record resolution~form|Resolution confirmation~success|Overdue grievance~warning',note='Six intake channels and 48-hour / 14-day deadlines are sandbox demonstrations, not approved national SLAs.')
module('KMS','Knowledge management','Knowledge author','Source-led redesign','openg2p-lab/registration-ui/knowledge-editor.html','/registration/knowledge','Service|Audience|Workflow stage|Title|Purpose|Steps|Requirements|Next step|Common issues|Visibility|Review due date','KM-DEMO-001;Correct a household;Published|KM-DEMO-002;Review evidence;In review|KM-DEMO-003;Payment exception;Draft',
 'Knowledge library~cards|Search results~list|No guidance results~empty|Published task guidance~article|Guidance feedback recorded~success|Contextual workflow help~article|Editorial work queue~list|Create guidance draft~editor|AI drafting instructions~form|AI suggestion review~article|Draft saved~success|Independent editorial review~checklist|Return with review feedback~form|Review approved~success|Publish confirmation~confirm|Published revision~success|Version and action history~timeline|Archive confirmation~confirm|Archived guidance~warning|Restore as draft~confirm|Version conflict~error',note='Authors cannot review their own draft. A verifier reviews; a supervisor publishes. The previous publication stays live while a new draft is edited. AI never publishes automatically.')
module('CMS','Public content management','Content editor','Source-led demonstration','openg2p-lab/registration-ui/phase1-cms.html','/registration/phase1/cms','Content type|Language|Title|Summary|Body|Location reference|Publication status|Review note','CMS-DEMO-001;Programme page / English;Published|CMS-DEMO-002;News / Hausa;Draft|CMS-DEMO-003;Service location / Yoruba;In review',
 'CMS content directory~list|Create content revision~editor|Language versions~list|Translation missing~warning|Submit revision for review~confirm|Independent content review~checklist|Return revision~form|Publish reviewed revision~confirm|Published content~success|Archive public content~confirm|Revision history~timeline',note='English, Hausa, Yoruba and Igbo are demonstrated; copy and translation approval remain pending. Prototype uses English labels with language selectors.')
module('PORT','Beneficiary and public portal','Beneficiary / assisted applicant','Source-led demonstration','openg2p-lab/registration-ui/phase1-public.html','https://beneficiary.nigeriag2p.com/selfservice','Programme|Household reference|Preferred language|Support location|Application information','DEMO-HHS;Household support;Programme details|DEMO-APP-001;Existing application;Submitted|DEMO-LOC-001;Demo support desk;Kano',
 'Public programme discovery~cards|Programme details~article|Language selection~list|Find a support location~list|Beneficiary sign-in~form|My support dashboard~dashboard|Existing application detail~detail|Application form prototype~form|Application validation error~error|Application submitted~success|Track application~timeline|Raise a grievance~form|Help and support~article',mobile=True,note='Direct registration/application is a portal UX prototype. It does not automatically feed PBMS 3; core CCT intake starts with approved NSR records. No translations are claimed as approved.')
module('ANL','Operational and knowledge analytics','Programme supervisor','Source-led redesign','openg2p-lab/registration-ui/analytics.html','/registration/analytics','Programme for operations|State for operations|Knowledge service|Knowledge events from (UTC)|Through (UTC)','Intake operations;Current snapshot;Separate scope|Native backend sources;Global aggregates;15-minute refresh|Knowledge usage;UTC date window;No query text',
 'Analytics overview~dashboard|Filter analytics scope~form|Intake operations~dashboard|Knowledge governance~dashboard|Guidance usage~chart|Source freshness~list|Stale source warning~warning|Source refresh failed~error|Export aggregate CSV~confirm|Export permission denied~error|No events in date window~empty',note='Dates filter usage/review events, not current operational counts. Native sources do not inherit intake filters. Opens are not unique readers. No settled-payment or contextual-help usage metric.')
module('GEO','Geographic record insights','Programme supervisor','Source-led redesign','openg2p-lab/registration-ui/geography.html','/registration/geography','Zone|State / FCT|Known LGA|Record type','North West;Kano;Synthetic record counts|South West;Lagos;Synthetic record counts|North Central;FCT;Synthetic record counts',
 'Geographic overview~chart|State record counts~list|LGA record counts~list|Unmapped geographic records~warning|Location data detail~detail',note='Demo LGA mapping is incomplete. No national 774-LGA coverage or geographic access boundary is implied.')
module('ODK','Field data collection administration','Field supervisor','Proposed native reference','openg2p-lab/README.md','https://odk.nigeriag2p.com/','Project|Form title|Form version|Assigned collectors|Submission reference','DEMO-PROJECT;Household field study;Draft|DEMO-FORM-001;Collection form;Published|DEMO-SUB-001;Submission;Review',
 'Collection projects~list|Project forms~list|Publish form version~upload|Assign collectors~form|Submissions review~list|Submission detail~detail',note='ODK Central was reachable in the source review; these task screens are proposed native reference layouts.')
module('MDM','Master data administration','Reference data administrator','Proposed native reference','openg2p-lab/persona-ui/src/catalogue.js','https://master-data-ui.nigeriag2p.com/','Dataset|Code|Display name|Parent location|Validity date','State / FCT;37 demo codes;Reference set|LGA;6 demo LGAs;Incomplete|Programme categories;Demo labels;Review',
 'Reference datasets~list|Dataset values~list|Create reference value~form|Duplicate code error~error|Approve reference change~confirm|Reference change recorded~success',note='NG01–NG37 are local lab codes, not official administrative codes. Dataset approval remains required.')
module('IAM','Staff access administration','Access administrator','Proposed native reference','openg2p-lab/persona-ui/src/catalogue.js','https://iam-staff-ui.nigeriag2p.com/','Staff identifier|Organisation|Requested role|Scope justification|Expiry date|Approval reason','DEMO-USER-001;Registration officer;Active|DEMO-USER-002;Verification officer;Active|DEMO-USER-003;Access request;Pending',
 'Staff accounts~list|Staff account detail~detail|Request role assignment~form|Independent access approval~checklist|Role assignment confirmation~confirm|Account suspended~warning|Audit access history~timeline',note='Role and scope designs require security-owner approval. Prototype actions do not grant access.')
module('SUP','NSIPA Analytics','Reporting analyst','Source-led / native reference','openg2p-lab/Analytics-Operations.md','https://superset.nigeriag2p.com/superset/dashboard/nigeria-platform-analytics/','Dashboard|Metric source|Reporting timestamp (UTC)|Chart','Aggregate metrics;Read-only reporting;Available|Knowledge governance;Read-only reporting;Available|Knowledge daily usage;Read-only reporting;Available',
 'Reporting dashboards~cards|Nigeria platform analytics~dashboard|Aggregate source metrics~list|Knowledge publishing metrics~chart|Knowledge daily usage~chart|Dataset access denied~error',note='Source installation has three table charts and read-only datasets; chart treatment here is a proposed visual redesign.')
module('PADMIN','Portal programme administration','Portal programme administrator','Native reference redesign','openg2p-lab/README.md','https://portal-admin.nigeriag2p.com/web','Portal programme|Form version|Application reference|Review outcome','DEMO-PORTAL-HHS;Compatible portal backend;Enabled|DEMO-APP-001;Portal application;Submitted|DEMO-CONNECTOR;PBMS 3 connector;Pending',
 'Portal programmes~list|Programme application form~editor|Portal applications~list|Application review~detail|Backend compatibility warning~warning',note='Separate portal database supports an earlier programme model. Do not imply an implemented portal-to-PBMS3 connector.')
module('SIM','Payment and partner simulations','Demo facilitator','Source-led demonstration','openg2p-lab/registration-ui/simulation.html','/registration/simulation','Scenario|Fictional instruction|Expected bank response|Demonstration note','Successful payment;Simulated outcome;Ready|Delayed or failed payment;Simulated outcome;Ready|Reversal or mismatch;Simulated outcome;Ready',
 'Simulation scenario library~cards|Configure fictional run~form|Simulated account rejection~error|Simulated payment accepted~success|Simulated delay~warning|Simulated failure~error|Simulated reversal~warning|Simulated mismatch~detail|Simulation run evidence~timeline',note='Synthetic scenario simulator; no real payment, message, identity or bank outcome occurs.')
module('OPS','Supporting service consoles','Platform operator','Proposed console reference','openg2p-lab/README.md','https://staff-portal.nigeriag2p.com/','Service|Resource reference|Environment|Read-only operation','MinIO;Object storage;Native console|Kafka;Event streams;Native console|Keycloak;Identity realm;Native console',
 'Staff application launcher~cards|Storage objects reference~list|Event topics reference~list|Identity realm reference~list|Artefact repository reference~list|Certificate service reference~detail|Identity verification reference~detail|Key manager service reference~detail|Service unavailable~error',note='MinIO, Kafka, Keycloak, Artifactory, Inji/eSignet and key manager are supporting products. These proposed overview designs do not replace their complete native administration interfaces. API-only services have no claimed original UI.')
module('UAT','Readiness and acceptance evidence','PMO reviewer','Source-led redesign','openg2p-lab/registration-ui/phase1-readiness.html','/registration/phase1/readiness','Module|Evidence category|Test date|Acceptance owner','Native integration;Fixture evidence;Available|Offline 48 hours;Device duration test;Pending|Formal NSIPA UAT;Agency acceptance;Not run',
 'Module readiness register~list|Integration evidence~detail|Outstanding acceptance gates~checklist|Review evidence export~confirm',note='A prototype does not establish production readiness. Agency acceptance, private native screens, channels and policy remain gates.')


module('DSH','Connected service dashboards','Programme supervisor','Source-led implemented sandbox','openg2p-lab/Service-Dashboards-Handover.txt','/registration/analytics','Service|Source|Dataset classification|Refresh timestamp','Registry;Native aggregate;Role scoped|PBMS;Programme aggregate;Role scoped|Field;Synthetic demo;Separate from native', 'Service overview~dashboard|Choose native or demo data~list|Dashboard chart and status drilldown~chart|Open filtered records~list|Source freshness and refresh~detail|Access restricted~warning',note='Sandbox aggregates; permissions and source freshness apply. Demo data is separate.')
module('ATL','Nigeria territorial intelligence','Public visitor','Source-led public atlas','openg2p-lab/territory-data/index.html','/territories/','Geographic view|State or FCT|Constituency|Source and year|Classification','Administrative areas;Service delivery geography;Published data|Constituencies;Electoral profile;Separate geography|Economic figures;Published or modelled;Source and year', 'Public territorial atlas~dashboard|Choose administrative area~list|Choose constituency profile~list|Map and rankings~chart|Economic measures and sectors~detail|Representative and sourced performance~detail|Missing comparable figure~empty',note='Administrative and electoral geographies use validated mappings; gaps remain gaps.')
module('JOS','Jos cash transfer pilot demo','Demo facilitator','Source-led synthetic walkthrough','openg2p-lab/persona-ui/src/jos-cct.jsx','/jos-cct/','Pilot budget USD|Sample beneficiary|Registry status|Approval step|Payment simulation','Pilot budget;USD 1.5 million;Proposal|Beneficiary;Fictional sample;Demo|Payments;Simulation only;No real transfers', 'Jos pilot overview~dashboard|Sample beneficiary~form|Registry registration~detail|Programme enrolment~detail|Approval service~checklist|Payment simulation~confirm|Reconciliation results~success|Guided walkthrough~list',note='Synthetic households; simulated payments only; no real money moves.')
module('MOB','Android field collection demo','Enumerator / supervisor','Source-led sample-only Android','openg2p-lab/field-app/android/README.md','/field-preview/android/','Enumerator sample ID|Visit date|Consent|State / FCT|Local government area|Ward|Latitude|Longitude','SAMPLE-VIDEO-04;Fictional record;Draft|Offline sample;Demo PIN review;Approved demo|ODK Central;Background upload;Sent', 'Field workspace~dashboard|Visit and consent~form|Search state and LGA~form|Choose ward and coordinates~form|Household sample details~form|Needs and livelihood~form|Save and reopen draft~detail|Supervisor demo PIN review~confirm|Offline queue~warning|Automatic sync and receipt~success|Upload failed and retry~error|iPhone and iPad preview~detail',mobile=True,note='Sample only. Demo PIN is not staff authentication; iOS preview has no server sync.')

# Semantic links are explicit, and all remaining states are exposed through each
# module's journey index. Links are design-only transitions; no external API call.
LINKS={
 'MBR':{0:[('Open household',1),('Review cases',7)],1:[('Correct details',3),('View members',2)],3:[('Submit correction',6),('Show validation error',4),('Discard changes',5)],4:[('Correct fields',3)],5:[('Keep editing',3),('Discard changes',1)],6:[('Open review checklist',7)],7:[('Approve registration',10),('Return for correction',8)],8:[('Send correction reason',9)],9:[('Correct household',3)],10:[('Confirm approval',11),('Cancel',7)],11:[('View synchronisation',12)],12:[('View connected result',14),('View conflict',13)],13:[('Review original record',1)],14:[('View activity',15)]},
 'KMS':{0:[('Search guidance',1),('Open editorial queue',6)],1:[('Read guidance',3),('No results example',2)],2:[('Clear filters',0)],3:[('Helpful',4),('Open contextual help',5)],6:[('Create guidance',7),('Review draft',11)],7:[('Save draft',10),('Draft with local AI',8),('Show version conflict',20)],8:[('Generate suggestion',9)],9:[('Apply to draft',7)],10:[('Submit for review',11)],11:[('Approve review',13),('Return to author',12)],12:[('Return draft',7)],13:[('Review publication',14)],14:[('Publish reviewed guidance',15),('Cancel',13)],15:[('View version history',16),('Archive guidance',17)],17:[('Confirm archive',18)],18:[('Restore draft',19)],19:[('Restore as draft',7)],20:[('Refresh original draft',7)]},
 'BRG':{2:[('Review dispatch',3),('View exceptions',8)],3:[('Authorise dispatch',4),('Cancel',2)],4:[('View bank response',5)],5:[('Upload statement',6)],6:[('Reconcile statement',7),('Duplicate example',12)],7:[('Inspect mismatch',8),('View fixture credit',11)],8:[('Review callback retry',9),('View reversal',10)],9:[('Retry callback',5)]},
 'ANL':{0:[('Filter scope',1),('View knowledge usage',4)],1:[('Apply filters',2),('Show empty result',10)],2:[('View native sources',5),('Review aggregate export',8)],5:[('View stale source',6),('View failed refresh',7)],6:[('Inspect freshness',5)],7:[('Review last valid result',5)],8:[('Confirm aggregate export',0),('Denied role example',9)],9:[('Return to analytics',0)]},
 'FLD':{0:[('Capture proof',2),('Check offline readiness',1)],2:[('Save on device',4),('Mismatch example',3)],3:[('Correct proof',2)],4:[('Open device queue',5)],5:[('Synchronise queue',6)],6:[('View synced proof',8),('View conflict',7)],7:[('Inspect assignment',0)],9:[('Return to assignments',0)]},
 'PBMS':{3:[('Validate NSR records',4)],4:[('Review beneficiary list',6),('View exceptions',5)],6:[('Approve enrolment',7)],7:[('Calculate benefits',8)],8:[('Review disbursement batch',9)],10:[('Submit evidence for verification',11)],11:[('Review release or hold',12)],12:[('Release eligible fixture',14),('Hold evidence',13)]},
 'GRM':{0:[('Register grievance',1),('Open case',4)],1:[('Submit grievance',3),('Show validation error',2)],2:[('Correct grievance',1)],3:[('Open case and deadlines',4)],4:[('Acknowledge case',5),('Escalate case',6),('Record resolution',8)],5:[('Confirm acknowledgement',4)],6:[('Send escalation',7)],7:[('Open case',4)],8:[('Save resolution',9)],10:[('Escalate overdue case',6)]},
 'PORT':{0:[('View programme',1),('Choose language',2)],1:[('Open my support',5),('Find support location',3)],4:[('Sign in to demo',5)],5:[('Track application',10),('Open application prototype',7)],7:[('Submit demo application',9),('Show validation error',8)],8:[('Correct application',7)],9:[('Track application',10)],10:[('Get help',12),('Raise grievance',11)],11:[('Review support guidance',12)]},
 'AUTH':{0:[('Staff sign-in',1),('Beneficiary sign-in',6)],1:[('Sign in to design demo',5),('Invalid credentials',2)],2:[('Try sign-in again',1)],3:[('Choose another workspace',0)],4:[('Sign in again',1)],5:[('Choose destination',0)],6:[('Enter beneficiary design demo',5)]},
 'CMS':{0:[('Create revision',1),('Review language versions',2)],1:[('Submit for review',4)],2:[('Review missing translation',3)],4:[('Confirm submission',5)],5:[('Approve content',7),('Return for changes',6)],6:[('Edit revision',1)],7:[('Publish revision',8)],8:[('Review archive action',9),('View revision history',10)]}}

LINKS.update({
 'HOME':{0:[('Officer workspace',1),('Verifier workspace',2),('Supervisor workspace',3)],1:[('View service catalogue',0)],2:[('View service catalogue',0)],3:[('View service catalogue',0)],4:[('View service catalogue',0)],5:[('Review assigned services',0)]},
 'REG':{0:[('Browse individuals',1),('Browse households',3)],1:[('Open individual',2),('Empty search example',7)],2:[('Request demographic change',5)],3:[('Review membership',4)],4:[('Request a change',5)],5:[('Submit change request',6)],6:[('Return to registry',0)],7:[('Clear search',1)]},
 'RADM':{0:[('Open household',1),('Review import results',3)],1:[('Edit membership',2)],2:[('Save membership change',4)],3:[('Return to administration',0)],4:[('Return to household',1)]},
 'AWE':{0:[('Open approval task',1)],1:[('Review evidence',2)],2:[('Review approval',3),('Return request',4)],3:[('Confirm approval',5),('Cancel',2)],4:[('Return with reason',0)],5:[('View callback delivery',6),('View callback failure',7)],6:[('Return to assigned tasks',0)],7:[('Review callback retry',5)]},
 'SPAR':{0:[('Browse account links',1),('Resolve an account',6)],1:[('Link account',2)],2:[('Review link details',4),('Show validation failure',3)],3:[('Correct link details',2)],4:[('Confirm link update',5),('Cancel',2)],5:[('Resolve linked account',6)],6:[('View resolution result',7),('No account example',8)],7:[('Return to account links',1)],8:[('Review account mapping',1)]},
 'PAR':{0:[('Review partners',1),('Manage agents',5)],1:[('Start onboarding',2)],2:[('Submit onboarding',3)],3:[('Approve demo partner',4)],4:[('Return to partner directory',1)],5:[('Record agent training',6),('Review certification',7)],6:[('Review certification',7)],7:[('Confirm certification',8)],8:[('Review revocation',9),('Return to agent directory',5)],9:[('Confirm revocation',10),('Cancel',5)],10:[('Review agent directory',5)]},
 'CON':{0:[('Open consent receipt',1),('Create consent request',2)],1:[('Review withdrawal',4),('Expired example',6)],2:[('Review request',3)],3:[('Confirm demo request',0),('Cancel',2)],4:[('Confirm withdrawal',5),('Cancel',1)],5:[('Return to consent directory',0)],6:[('Review consent directory',0)]},
 'GEO':{0:[('Browse states',1),('Review unmapped records',3)],1:[('Browse known LGAs',2)],2:[('Open location data',4)],3:[('Review location data',4)],4:[('Return to geographic overview',0)]},
 'ODK':{0:[('Open collection project',1)],1:[('Review form version',2),('Assign collectors',3),('Review submissions',4)],2:[('Validate demo form',1)],3:[('Save demo assignment',1)],4:[('Open submission',5)],5:[('Return to submissions',4)]},
 'MDM':{0:[('Open reference dataset',1)],1:[('Create reference value',2)],2:[('Review reference change',4),('Duplicate example',3)],3:[('Correct reference code',2)],4:[('Confirm approved demo change',5),('Cancel',2)],5:[('Return to dataset',1)]},
 'IAM':{0:[('Open staff account',1)],1:[('Request role assignment',2),('View access history',6),('Suspended example',5)],2:[('Submit access request',3)],3:[('Review assignment decision',4)],4:[('Confirm demo assignment',6),('Cancel',1)],5:[('Review account detail',1)],6:[('Return to staff directory',0)]},
 'SUP':{0:[('Open platform dashboard',1)],1:[('Review source metrics',2),('View governance',3),('View daily usage',4)],2:[('Return to reporting',1),('Access denied example',5)],3:[('Return to reporting',1)],4:[('Return to reporting',1)],5:[('Return to dashboards',0)]},
 'PADMIN':{0:[('Review programme form',1),('Browse portal applications',2),('Review compatibility',4)],1:[('Save demo form',0)],2:[('Open portal application',3)],3:[('Return to applications',2)],4:[('Return to programmes',0)]},
 'SIM':{0:[('Configure scenario',1)],1:[('Account rejection',2),('Payment accepted',3),('Payment delayed',4)],2:[('Review run evidence',8)],3:[('Review run evidence',8)],4:[('Review run evidence',8)],5:[('Review run evidence',8)],6:[('Review run evidence',8)],7:[('Review run evidence',8)],8:[('Choose another scenario',0)]},
 'OPS':{0:[('Storage reference',1),('Event topics reference',2),('Identity realm reference',3)],1:[('Return to service launcher',0)],2:[('Return to service launcher',0)],3:[('Return to service launcher',0)],4:[('Return to service launcher',0)],5:[('Return to service launcher',0)],6:[('Return to service launcher',0)],7:[('Return to service launcher',0)],8:[('Review service launcher',0)]},
 'UAT':{0:[('Review integration evidence',1),('Review acceptance gates',2)],1:[('Review outstanding gates',2)],2:[('Review evidence export',3)],3:[('Confirm demo evidence export',0),('Cancel',2)]}
})

TASK_FIELDS={
 ('AUTH',1):['Staff ID','Password'],('AUTH',6):['Beneficiary identifier','Password'],
 ('MBR',8):['Household reference','Correction reason (at least 10 characters)'],
 ('MBR',16):['Approved NSR reference','Household name','State / FCT','LGA','Community','Source verification note'],
 ('REG',5):['Individual reference','Field to change','Current value','Proposed value','Change reason','Evidence reference'],
 ('RADM',2):['Household reference','Member reference','Relationship','Effective date','Change justification'],
 ('PBMS',2):['Programme name','Benefit amount (NGN)','Cycle','Approved NSR source','Eligibility rule version','Programme owner'],
 ('PBMS',10):['Beneficiary reference','Attendance percentage (demo)','Evidence period','Evidence reference','Evidence officer','Submission note'],
 ('AWE',4):['Task reference','Return reason','Requested correction','Evidence reference'],
 ('SPAR',2):['Beneficiary reference','Bank code','Masked account reference','Account type','Update reason'],
 ('SPAR',6):['Beneficiary reference','Resolution purpose'],
 ('BRG',6):['Statement reference','Bank route','Statement date','Currency','Batch reference'],
 ('FLD',2):['Household reference','Certified agent reference','Mock biometric result','Test location coordinates'],
 ('PAR',2):['Partner name','Organisation type','Territory','Partner owner','Onboarding evidence'],
 ('PAR',6):['Agent reference','Training module','Training date','Completion evidence','Trainer reference'],
 ('CON',2):['Subject reference','Purpose','Data scope','Expiry date','Consent wording version'],
 ('GRM',1):['Household reference','Intake channel (simulated)','Issue category','Issue description','Preferred contact channel'],
 ('GRM',6):['Case reference','Escalation reason','Escalation owner','Required next action'],
 ('GRM',8):['Case reference','Resolution note','Resolution category','Supporting evidence'],
 ('KMS',8):['Service','Audience','Workflow stage','Drafting instructions'],
 ('KMS',12):['Guidance reference','Return reason (at least 10 characters)','Requested corrections'],
 ('CMS',1):['Content type','Language','Title','Summary','Body','Location reference','Review note'],
 ('CMS',6):['Content reference','Language','Return reason','Requested corrections'],
 ('PORT',4):['Beneficiary identifier','Password'],
 ('PORT',7):['Programme reference','Existing household reference','Application information','Preferred language'],
 ('PORT',11):['Household reference','Issue category','Issue description','Preferred support channel'],
 ('ANL',1):['Programme for operations','State for operations','Knowledge service','Knowledge events from (UTC)','Through (UTC)'],
 ('ODK',3):['Project reference','Form version','Collector group','Assignment expiry'],
 ('MDM',2):['Dataset','Code','Display name','Parent location','Validity date'],
 ('IAM',2):['Staff identifier','Requested role','Organisation','Scope justification','Expiry date'],
 ('SIM',1):['Fictional instruction','Scenario','Expected simulated response','Demonstration note']}

STATE_COPY={
 ('MBR',6):'Correction saved and sent for independent verification. The registration is not yet approved.',
 ('MBR',9):'A verifier returned this case with a correction reason. The officer must amend it and resubmit.',
 ('MBR',11):'The independent registration decision is approved. Registry synchronisation is tracked separately.',
 ('MBR',12):'The registration decision is approved, but registry synchronisation has not completed. Do not repeat the approval.',
 ('PBMS',13):'Demonstration evidence is below the configured 80% threshold. Hold the fixture; do not release it.',
 ('PBMS',14):'Bridge accepted the fictional instruction batch. This status is not confirmation of bank settlement.',
 ('AWE',5):'The task decision is recorded. Signed callback delivery is still pending.',
 ('BRG',4):'The instruction was accepted for dispatch. A bank response or settlement outcome has not been established.',
 ('BRG',11):'A fictional local Example Bank credit is represented here. This is not evidence of a real payment.',
 ('FLD',4):'Proof is saved only on this device. It has not yet reached the server.',
 ('FLD',6):'Queued proof is being synchronised. A retry must preserve its original idempotency reference.',
 ('FLD',8):'The demonstration server accepted the proof. The device queue can mark this item synchronised.',
 ('KMS',10):'A draft revision was saved. The previous published version remains live; this draft is not published.',
 ('KMS',13):'An independent reviewer approved this version. A permitted supervisor must still publish it.',
 ('KMS',15):'The reviewed revision is now the fictional live version. Its publication history is retained.',
 ('KMS',18):'Archived guidance is hidden from the library and contextual help; its history is retained.',
 ('CMS',3):'A required language version is missing or unapproved. Do not describe the content as fully translated.',
 ('ANL',6):'This source is older than the 30-minute warning threshold. Keep the last valid value and its UTC timestamp visible.',
 ('PADMIN',4):'The portal uses an earlier compatible programme model. An approved PBMS 3 connector or migration is still needed.'}


LINKS.update({
'DSH':{0:[('Choose source',1),('Open chart',2)],1:[('Open chart',2)],2:[('Open records',3),('Source freshness',4)],3:[('Return to dashboard',0)],4:[('Open chart',2)],5:[('Return to dashboard',0)]},
'ATL':{0:[('Administrative areas',1),('Constituencies',2)],1:[('View map',3)],2:[('View representative',5)],3:[('View economic data',4),('Missing data',6)],4:[('View map',3)],5:[('Return to atlas',0)],6:[('Return to atlas',0)]},
'JOS':{0:[('Start walkthrough',7),('Sample beneficiary',1)],1:[('Open registry',2)],2:[('Open programme',3)],3:[('Review approval',4)],4:[('Simulate payment',5)],5:[('View reconciliation',6)],6:[('Return to pilot',0)],7:[('Begin sample',1)]},
'MOB':{0:[('Start visit',1),('iOS preview',11)],1:[('Choose area',2)],2:[('Choose ward',3)],3:[('Household',4)],4:[('Needs',5)],5:[('Save draft',6)],6:[('Supervisor review',7)],7:[('Queue offline',8)],8:[('Show sync',9),('Retry failure',10)],9:[('Return to workspace',0)],10:[('Return to queue',8)],11:[('Return to workspace',0)]}
})
STATE_COPY.update({('MOB',7):'DEMO PIN only. This does not verify an independent supervisor identity.',('MOB',8):'Approved demo record remains on the device when offline. No personal data.',('MOB',9):'Sample uploaded to ODK Central after reconnection; server review remains separate.',('MOB',10):'The sample remains queued after failure and can be retried.',('ATL',6):'No comparable source is available. Keep the measure empty and disclose the gap.',('JOS',6):'Fictional reconciliation result; no real payment or settlement.'})

TASK_FIELDS.update({('MOB',1):['Enumerator sample ID','Visit date','Consent'],('MOB',2):['Search state or FCT','State or FCT','Search LGA','LGA'],('MOB',3):['Search ward','Ward','Latitude (optional)','Longitude (optional)'],('MOB',4):['Sample household reference','Household members','Children under 18','Shelter type'],('MOB',5):['Main livelihood','Priority support need']})

def safe(s):return re.sub('[^A-Za-z0-9_-]+','-',s).strip('-')

class Design:
 def __init__(self,name):
  self.cmd=[];self.refs={};self.links=[];self.module_refs={};self.components={};self.name=name;self.pages={};self.flow_refs=[]
  self.add('file.rename',name=name)
 def add(self,command,**params):
  step=len(self.cmd);self.cmd.append(dict(command=command,params=params));return {'$step':step}
 def node(self,typ,name,parent=None,x=0,y=0,w=100,h=40,text=None,**props):
  p=dict(type=typ,name=name,x=x,y=y,width=w,height=h,props=props,select=False)
  if parent is not None:p['parent']=parent
  if text is not None:p['text']=text
  return self.add('node.create',**p)
 def rect(self,p,x,y,w,h,fill='#FFFFFF',name='Surface',**props):return self.node('rectangle',name,p,x,y,w,h,fill=fill,**props)
 def text(self,p,x,y,w,text,size=16,color='#123E31',h=None,bold=False,name=None):
  return self.node('text',name or text[:60],p,x,y,w,h or (size*1.45),text=text,fontFamily='Segoe UI',fontSize=size,fontStyle='Bold' if bold else 'Regular',lineHeight=f'{int(size*1.45)}',fill=color,textAutoResize='height')
 def page(self,name,first=False):
  if first:
   self.add('page.rename',id=1,name=name);ref=1
  else:ref=self.add('page.add',name=name)
  self.pages[name]=ref
  self.add('page.select',id=ref);self.add('page.setBackground',id=ref,color='#E4EBE8')
  return ref
 def frame(self,p,name,x=0,y=0,w=1440,h=1040):
  return self.node('frame',name,p,x,y,w,h,fill='#F5F7F6',clip=True,pluginData={'ng2p.author':'Sathvick Infotech Private Limited','ng2p.baseline':'4 November 2026 / synthetic design'})
 def button(self,p,x,y,label,target=None,primary=True,w=230):
  # Native instances retain a shared background component. Visible label is an
  # editable text sibling so module labels remain readable across importers.
  comp=self.components.get('primary' if primary else 'secondary')
  if comp:
   bg=self.add('instance.create',component=comp,parent=p,x=x,y=y)
   self.add('node.set',id=bg,name=f'Button / {label}',width=w,height=44)
  else:bg=self.rect(p,x,y,w,44,'#006B45' if primary else '#FFFFFF',name=f'Button / {label}',cornerRadius=8,stroke='#006B45',strokeWeight=1)
  tx=self.text(p,x+14,y+11,w-28,label,14,'#FFFFFF' if primary else '#004E33',bold=True,h=24)
  if target:
   self.links.extend([(bg,target,label),(tx,target,label)])
  return bg
 def logo(self,parent,x,y,width,reverse=False):
  import xml.etree.ElementTree as ET,base64
  svg=ET.fromstring((ROOT/'assets/nsipa-wordmark.svg').read_text())
  svg.set('width',str(width));svg.set('height',str(width*110/410))
  data=ET.tostring(svg,encoding='unicode')
  if reverse:
   for color in ['#006B45','#123E31','#006b45','#123e31']:data=data.replace(color,'#FFFFFF')
  ref=self.add('file.import',data=base64.b64encode(data.encode()).decode(),name='NSIPA.svg')
  self.add('node.reparent',ids=[ref],parent=parent)
  self.add('node.set',id=ref,x=x,y=y,name='NSIPA / Editable vector identity')
  return ref
 def foundations(self):
  p=self.page('01 Foundations and components')
  f=self.frame(p,'NG2P-DS-001 / Foundations / D1440',w=1440,h=1040)
  self.text(f,52,40,1200,'NSIPA · Design foundations',36,bold=True)
  self.text(f,52,101,1250,'Sathvick Infotech Private Limited  /  editable components, semantic colours and screen naming',17)
  colors=[('Brand / Primary','#006B45'),('Text / Primary','#123E31'),('Surface / Canvas','#F5F7F6'),('State / Warning','#FFF1D8'),('State / Error','#FCE9E4'),('State / Success','#E5F3EA')]
  for i,(name,color) in enumerate(colors):
   self.rect(f,52+i*220,170,196,100,color,cornerRadius=12,stroke='#D8E3DD',strokeWeight=1)
   self.text(f,52+i*220,286,205,name,13,bold=True);self.text(f,52+i*220,312,205,color,13)
   self.add('style.create',type='paint',name=f'NG2P/{name}',value=[{'type':'solid','color':color}])
  for i,(key,color) in enumerate([('primary','#006B45'),('secondary','#FFFFFF')]):
   comp=self.node('component',f'NG2P/Button/{key.title()}',p,i*280,1150,230,44,fill=color,cornerRadius=8,stroke='#006B45',strokeWeight=1)
   self.components[key]=comp
  for i,(name,sz) in enumerate([('Display',36),('Heading',28),('Section',20),('Body',16),('Label',14),('Caption',12)]):
   ref=self.text(f,52,380+i*62,750,f'{name} / {sz} px · Clear next steps.',sz,bold=i<3)
   self.add('style.create',type='text',name=f'NG2P/Type/{name}',**{'from':ref})
  self.text(f,850,390,510,'Naming convention',24,bold=True)
  self.text(f,850,444,500,'NG2P-{MODULE}-{###} / {Task} / {Viewport} / {State}\n\nD1440 = desktop 1440 × 1040\nM390 = mobile 390 × 844\n\n8 px spacing grid · 44 px buttons\nForm labels stay visible\nErrors explain recovery\nStatus uses text as well as colour\nReview and publish remain separate',16,h=450)
  self.logo(f,52,800,240)
  self.text(f,325,816,900,'Shared Progress · NSIPA identity / Green #006B45 / Gold #D5A63C',17)
  self.add('style.create',type='paint',name='NSIPA/Brand/Gold',value=[{'type':'solid','color':'#D5A63C'}])
  self.text(f,52,930,1280,'Design review targets: keyboard order, focus visibility, contrast, plain language, screen-reader names and real-device usability still require implementation testing.',14)
  # A real reusable component set, placed beneath the foundation frame.
  for i,(name,fill,w,h) in enumerate([('Card/Default','#FFFFFF',320,160),('Input/Default','#FFFFFF',320,48),('Badge/Warning','#FFF1D8',160,32),('Badge/Success','#E5F3EA',160,32),('Alert/Error','#FCE9E4',460,64),('Divider/Default','#D8E3DD',400,1)]):
   c=self.node('component','NG2P/'+name,p,(i%3)*500,1280+(i//3)*230,w,h,fill=fill,cornerRadius=8,stroke='#D8E3DD',strokeWeight=1)
   self.components[name]=c
 def cover(self,mods):
  p=self.page('00 Start and service map',first=True)
  f=self.frame(p,'NG2P-START-001 / Service map / D1440',w=1440,h=1300)
  self.refs['START']=f
  self.rect(f,0,0,1440,14,'#006B45')
  self.logo(f,52,40,270)
  self.text(f,52,128,1250,'UX / UI design and interactive journey library',28)
  self.text(f,52,185,1300,f'{sum(len(m["screens"]) for m in mods)} task and state screens · {len(mods)} application areas · Desktop and mobile',19)
  self.text(f,52,226,1320,'Prepared by Sathvick Infotech Private Limited  /  4 November 2026  /  Design baseline v3.0',15)
  self.rect(f,52,276,1336,80,'#FFF1D8',cornerRadius=10)
  self.text(f,72,292,1290,'SOURCE-LED DESIGN BASELINE · Synthetic data only. Private native screens are proposed references.\nThis design package does not certify that every upstream application screen has been inspected.',16,h=58)
  for i,m in enumerate(mods):
   x=52+(i%3)*452;y=394+(i//3)*92
   self.button(f,x,y,m['code']+' · '+m['name'],m['screens'][0]['id'],w=432)
   self.text(f,x,y+51,432,f'{len(m["screens"])} screens  /  {m["evidence"]}',12)
  self.flow_refs.append((f,'00 · NSIPA service map'))
 def shell(self,m,s,idx,page):
  mobile=m['mobile'];w,h=(390,844) if mobile else (1440,1040)
  name=f'{s["id"]} / {s["title"]} / {s["viewport"]} / {s["state"]}'
  f=self.frame(page,name,(idx%4)*(w+100),(idx//4)*(h+140),w,h);self.refs[s['id']]=f
  self.add('node.set',id=f,pluginData={'ng2p.source':f'{m["name"]} | Role: {m["role"]} | {m["evidence"]} | Source: {m["source"]} | Route: {m["route"]} | {m["note"]}'})
  if mobile:
   self.rect(f,0,0,w,60,'#123E31');self.logo(f,18,10,145,reverse=True)
   self.text(f,18,76,355,m['role'].upper(),11)
   self.text(f,18,101,354,s['title'],25,h=76,bold=True)
   self.text(f,18,176,354,m['code']+' / '+s['id']+' · DEMONSTRATION',10)
   x,y,cw=18,212,354
   self.rect(f,0,784,w,60,'#FFFFFF');self.button(f,12,791,'Journey index',m['screens'][0]['id'],False,w=174)
   self.button(f,198,791,'All services','START',False,w=180)
  else:
   self.rect(f,0,0,1440,34,'#123E31');self.text(f,24,7,1200,'NSIPA / SYNTHETIC DESIGN DEMONSTRATION',12,'#FFFFFF')
   self.rect(f,0,34,236,1006,'#FFFFFF');self.rect(f,236,34,1204,70,'#FFFFFF')
   self.logo(f,24,57,185)
   self.text(f,24,112,194,'STAFF SERVICES',11)
   nav=[('Service map','START'),('Journey index',m['screens'][0]['id'])]
   if not self.name.startswith('NG2P-'+m['code']):nav += [('Knowledge','NG2P-KMS-001'),('Analytics','NG2P-ANL-001')]
   for i,(label,target) in enumerate(nav):self.button(f,18,160+i*60,label,target,False,w=200)
   self.text(f,24,475,185,m['name'],18,bold=True,h=72)
   self.text(f,24,565,185,'ROLE\n'+m['role'],13,h=90)
   self.text(f,24,790,185,'Design baseline v3.0\nSathvick Infotech\nPrivate Limited\n\nNo live transactions',12,h=160)
   self.text(f,274,59,850,m['name'],16,bold=True)
   self.text(f,1190,59,220,'DEMO WORKSPACE',12)
   self.text(f,278,131,1080,m['code']+' / '+s['id']+' / '+m['evidence'],11)
   self.text(f,278,165,1090,s['title'],32,bold=True,h=55)
   self.text(f,278,220,1080,'Review the source, current state and next action.',16)
   self.rect(f,278,264,1114,56,'#EAF2EC',cornerRadius=8)
   note='Design-only reference. '+m['note'] if 'Proposed' in m['evidence'] or 'private' in m['evidence'] else m['note'] or 'Source-led redesign; synthetic records and proposed presentation.'
   self.text(f,294,276,1080,note,12,h=40)
   x,y,cw=278,346,1114
   self.text(f,278,994,1100,s['id']+'  |  '+m['role']+'  |  Prototype data and outcomes are fictional',11)
  self.body(f,m,s,x,y,cw,mobile)
  return f
 def body(self,f,m,s,x,y,cw,mobile):
  k=s['kind'];rows=m['rows'];title=s['title'];maxbody=448 if mobile else 500
  index=int(s['id'].split('-')[-1])-1;task=(m['code'],index)
  if m['code']=='JOS' and index==0:
   self.rect(f,x,y,cw,450,'#FFFFFF',cornerRadius=12)
   for i,(label,value,sub) in enumerate([('PILOT BUDGET','USD 1.5 million','Planning budget'),('BENEFICIARIES','Fictional samples','Demonstration only'),('PAYMENTS','Simulated','No real transfers')]):
    cx=x+20+i*350;self.rect(f,cx,y+24,330,132,'#F2F7F3',cornerRadius=10);self.text(f,cx+16,y+36,298,label,12,bold=True);self.text(f,cx+16,y+67,298,value,24,bold=True);self.text(f,cx+16,y+112,298,sub,12)
   self.text(f,x+24,y+205,cw-48,'Registry  →  Programme  →  Approval  →  Simulated payment  →  Reconciliation',18,bold=True)
   self.text(f,x+24,y+275,cw-48,'The walkthrough uses sample beneficiaries and a simulated payment path.',15)
   return
  if m['code']=='ATL' and index==0:
   self.rect(f,x,y,cw,450,'#FFFFFF',cornerRadius=12)
   self.text(f,x+24,y+26,cw-48,'Two connected geographic views',24,bold=True)
   self.text(f,x+24,y+90,cw-48,'Administrative areas  ·  Service delivery',19,bold=True)
   self.text(f,x+24,y+145,cw-48,'Electoral constituencies  ·  Representation and profiles',19,bold=True)
   self.text(f,x+24,y+218,cw-48,'Each measure: source  /  year  /  geographic level  /  classification',16)
   self.text(f,x+24,y+278,cw-48,'Published data, modelled estimates and synthetic demonstrations remain distinct. Unavailable measures stay empty.',15,h=72)
   return
  if m['code']=='MOB' and index==0:
   self.rect(f,x,y,cw,430,'#FFFFFF',cornerRadius=12)
   self.text(f,x+18,y+20,cw-36,'Sample visits',19,bold=True)
   self.text(f,x+18,y+75,cw-36,'SAMPLE-VIDEO-04  ·  Sent',15,h=42)
   self.text(f,x+18,y+140,cw-36,'Draft  →  Demo review  →  Offline queue  →  Sent',14,h=75)
   self.text(f,x+18,y+235,cw-36,'Sample data only. Demo PIN is not staff authentication.',13,h=90)
   return
  if m['code']=='MOB' and index==11:
   self.rect(f,x,y,cw,390,'#FFFFFF',cornerRadius=12)
   self.text(f,x+18,y+20,cw-36,'iPhone / iPad web preview',18,bold=True)
   self.text(f,x+18,y+65,cw-36,'Safari → Share → Add to Home Screen',14,h=60)
   self.text(f,x+18,y+140,cw-36,'Sample draft only. Supervisor authentication and server sync are not connected.',14,h=110)
   self.text(f,x+18,y+265,cw-36,'Do not enter real household information.',13,h=70)
   return
  if m['code']=='PORT' and index in [0,1,2,3,5,6,10]:
   self.rect(f,x,y,cw,448,'#FFFFFF',cornerRadius=12)
   content={
    0:[('Household support','Nigeria Household Support — Portal UX Demo'),('Programme information','Read the demonstration programme details before opening an application.'),('Existing households','Use an existing approved NSR reference for the Phase-1 CCT journey.'),('Need assistance?','Find a demonstration support location or read task guidance.')],
    1:[('Programme','Nigeria Household Support — Portal UX Demo'),('Demonstration benefit','NGN 25,000 per configured fixture cycle. Real eligibility rules require approval.'),('Before you start','Read the requirements and use only supplied fictional records.'),('Portal connection','An application here does not automatically enter PBMS 3.')],
    2:[('English','English demonstration content'),('Hausa','Demonstration language option'),('Yoruba','Demonstration language option'),('Igbo','Demonstration language option; translations need approval')],
    3:[('DEMO support desk · Kano','Dala demonstration location'),('DEMO support desk · Lagos','Ikeja demonstration location'),('DEMO support desk · FCT','AMAC demonstration location'),('Before visiting','These are fictional locations, not a verified public service directory.')],
    5:[('My household','DEMO-HH-001 · fictional support record'),('My application','DEMO-APP-001 · Submitted in the portal'),('Next step','Track your application or read the help guidance.'),('Need assistance?','Raise a demonstration grievance or find a support location.')],
    6:[('Application reference','DEMO-APP-001'),('Programme','Household support — Portal UX Demo'),('Portal status','Submitted · outcome pending'),('Important distinction','Portal application status is separate from PBMS 3 processing.')],
    10:[('1 · Application submitted','DEMO-APP-001 · portal record created'),('2 · Portal review pending','A current decision has not been provided.'),('3 · Check the recorded outcome','Do not assume enrolment or payment from submission alone.'),('PBMS 3 connection','Connector / migration remains an implementation gate.')]
   }[index]
   for i,(heading,body) in enumerate(content):
    yy=y+18+i*106
    self.text(f,x+18,yy,cw-36,heading,16,bold=True,h=45)
    self.text(f,x+18,yy+35,cw-36,body,13,h=65)
   return
  if m['code']=='KMS' and s['id'].endswith('001'):
   self.rect(f,x,y,cw,500,'#FFFFFF',cornerRadius=12)
   self.text(f,x+22,y+18,cw-44,'Find guidance for your current task',22,bold=True)
   self.rect(f,x+22,y+64,cw-44,44,'#F5F8F6',cornerRadius=7,stroke='#AFC3B9',strokeWeight=1)
   self.text(f,x+36,y+76,cw-72,'Search published guidance by task or service',14,'#63776D')
   self.text(f,x+22,y+130,cw-44,'All services     Registration     Programme management     Payments     Knowledge',14)
   for i,(name,summary) in enumerate([('Correct a returned household','Understand the return reason, edit the record and resubmit.'),('Review registration evidence','Use the independent verification checklist before deciding.'),('Understand a payment exception','Check instruction state and the approved exception path.')]):
    yy=y+180+i*96
    self.text(f,x+22,yy,cw-44,name,18,bold=True)
    self.text(f,x+22,yy+33,cw-44,summary+'  ·  DEMO guidance',14)
    self.rect(f,x+22,yy+76,cw-44,1,'#E0E9E3')
   return
  if k in ['error','warning','success','empty','confirm']:
   color={'error':'#FCE9E4','warning':'#FFF1D8','success':'#E5F3EA','empty':'#EDF1F0','confirm':'#E8F0F6'}[k]
   self.rect(f,x,y,cw,146 if mobile else 118,color,cornerRadius=12)
   self.text(f,x+18,y+18,cw-36,{'error':'Action needs attention','warning':'Review this state','success':'Demonstration outcome','empty':'Nothing to show in this scope','confirm':'Confirm before continuing'}[k],19,bold=True)
   msg={'error':'The request was not completed. Review the indicated fields or refresh the original record before retrying.','warning':'The outcome is pending or needs review. Check the current record before repeating an action.','success':'The displayed result is a fictional prototype state. Review history or return to the work queue.','empty':'No records match the selected filters. Clear filters or choose another date range.','confirm':'Review the reference and intended action. This prototype simulates the outcome; it does not change a live system.'}[k]
   msg=STATE_COPY.get(task,msg)
   self.text(f,x+18,y+54,cw-36,msg,14,h=88)
   if k=='error':
    self.text(f,x+18,y+174,cw-36,self.error_copy(m,s),15,h=100)
   else:self.details(f,m,x,y+(170 if mobile else 146),cw,mobile,limit=3,state=title)
  elif k in ['form','editor','upload']:
   self.rect(f,x,y,cw,maxbody,'#FFFFFF',cornerRadius=12)
   if k=='upload':
    self.rect(f,x+20,y+26,cw-40,140,'#EFF5F1',cornerRadius=8,stroke='#8EACA0',strokeWeight=1)
    self.text(f,x+40,y+49,cw-80,'Select demonstration file',21,bold=True)
    self.text(f,x+40,y+91,cw-80,'File selection is represented as a design state.\nValidate format, duplicates and references before import.',14,h=66)
   fields=TASK_FIELDS.get(task,m['fields'])[:(4 if mobile else 12)]
   start=y+190 if k=='upload' else y+22
   for i,label in enumerate(fields[:(2 if k=='upload' else len(fields))]):
    col=0 if mobile else i%2;row=i if mobile else i//2
    fw=cw-40 if mobile else (cw-60)/2
    fy=start+row*(76 if not mobile else 93)
    if fy+65>y+maxbody:break
    self.text(f,x+20+col*(fw+20),fy,fw,label,13,bold=True)
    self.rect(f,x+20+col*(fw+20),fy+26,fw,43,'#FFFFFF',cornerRadius=6,stroke='#AFC3B9',strokeWeight=1)
    val=self.field_value(m,label,i)
    self.text(f,x+32+col*(fw+20),fy+36,fw-24,val,12,'#63776D')
   if not mobile:
    self.text(f,x+8,y+maxbody+12,cw-16,'Demonstration values · all controls remain editable design layers',12)
  elif k in ['list','timeline','checklist']:
   self.rect(f,x,y,cw,maxbody,'#FFFFFF',cornerRadius=12)
   if k=='timeline':
    for i,event in enumerate(['Created / submitted','Independent review recorded','Next action pending','History retained']):
     self.rect(f,x+25,y+28+i*90,10,10,'#006B45',cornerRadius=5)
     self.text(f,x+54,y+20+i*90,cw-80,event,16,bold=True)
     self.text(f,x+54,y+50+i*90,cw-80,'DEMO event · actor and timestamp shown in implementation',12)
   elif k=='checklist':
    for i,tx in enumerate(['Check authoritative source and task evidence','Confirm role and permitted action','Review exceptions and unresolved items','Record an independent decision and reason']):
     self.rect(f,x+20,y+26+i*(94 if mobile else 88),22,22,'#FFFFFF',cornerRadius=4,stroke='#006B45',strokeWeight=1)
     self.text(f,x+56,y+25+i*(94 if mobile else 88),cw-78,tx,14,h=72)
    if not mobile:self.text(f,x+20,y+420,cw-40,'Checklist is a review design state; no approval is sent to a live system.',13)
   else:
    self.text(f,x+20,y+20,cw-40,'Search / filter demonstration records',14)
    self.rect(f,x+20,y+57,cw-40,1,'#D8E3DD')
    for i,row in enumerate(rows):
     ry=y+85+i*(105 if mobile else 100)
     if mobile:
      self.text(f,x+20,ry,cw-40,row[0],16,bold=True);self.text(f,x+20,ry+31,cw-40,' · '.join(row[1:]),12,h=50)
     else:
      self.text(f,x+22,ry,cw*.31,row[0],16,bold=True)
      self.text(f,x+cw*.36,ry,cw*.32,row[1],14)
      self.rect(f,x+cw*.73,ry-5,cw*.23,34,'#EDF4EF',cornerRadius=6)
      self.text(f,x+cw*.74,ry+2,cw*.21,row[2],12)
     self.rect(f,x+20,ry+77,cw-40,1,'#E4EBE6')
  elif k=='article':
   self.rect(f,x,y,cw,maxbody,'#FFFFFF',cornerRadius=12)
   sections=[('Purpose','Complete the current task with the correct role and approved evidence.'),('What you need','A current record reference, access to the task and the authoritative procedure.'),('What to do','1. Review the record.\n2. Check the evidence and permissions.\n3. Complete the next action and retain the reference.'),('Common issues','If the state is unknown or the record changed, refresh it before retrying.')]
   yy=y+20
   for heading,body in sections[:3 if mobile else 4]:
    self.text(f,x+20,yy,cw-40,heading,17,bold=True);self.text(f,x+20,yy+32,cw-40,body,14,h=92);yy+=120 if mobile else 113
  elif k=='detail':self.details(f,m,x,y,cw,mobile,limit=4,state=title)
  else:
   # Overview cards and an editable vector bar chart, using clearly marked demo values.
   count=2 if mobile else 3;cardw=cw if mobile else (cw-32)/3
   metric_labels=['Pending tasks','Needs review','Completed demo tasks']
   bar_labels=['Awaiting review','Needs correction','Completed']
   if m['code'] in ['ANL','SUP']:
    metric_labels=['Current household records','Pending verification','Sync exceptions']
    if index in [3] or (m['code']=='SUP' and index==3):
     metric_labels=['Live published guides','Awaiting editorial review','Draft revisions'];bar_labels=['Published payloads','In review','Draft revisions']
    if index==4:
     metric_labels=['Guide opens','Searches','Helpful votes'];bar_labels=['Guide opens','Zero-result searches','Helpful votes']
   for i in range(count):
    cx=x if mobile else x+i*(cardw+16);cy=y+i*112 if mobile else y
    self.rect(f,cx,cy,cardw,96,'#FFFFFF',cornerRadius=12)
    self.text(f,cx+18,cy+16,cardw-36,metric_labels[i],13)
    self.text(f,cx+18,cy+42,cardw-36,['12','3','8'][i],31,bold=True)
   cy=y+242 if mobile else y+122
   self.rect(f,x,cy,cw,195 if mobile else 340,'#FFFFFF',cornerRadius=12)
   self.text(f,x+20,cy+17,cw-40,'Demonstration activity' if k=='chart' else 'Work requiring attention',18,bold=True)
   if k in ['chart','dashboard'] and not mobile:
    for i,(label,amount) in enumerate(zip(bar_labels,[.73,.28,.62])):
     self.text(f,x+24,cy+78+i*72,205,label,14)
     self.rect(f,x+240,cy+78+i*72,cw-290,24,'#EEF3F0',cornerRadius=4)
     self.rect(f,x+240,cy+78+i*72,(cw-290)*amount,24,'#006B45',cornerRadius=4)
    self.text(f,x+24,cy+296,cw-48,'Illustrative counts only · no live backend connection',12)
   else:
    for i,row in enumerate(rows[:2 if mobile else 3]):self.text(f,x+20,cy+65+i*56,cw-40,' · '.join(row),13,h=45)
 def details(self,f,m,x,y,cw,mobile,limit=4,state=None):
  hh=min(360,limit*(78 if mobile else 70)+30)
  self.rect(f,x,y,cw,hh,'#FFFFFF',cornerRadius=12)
  pairs=[('Reference',m['rows'][0][0]),('Current state',state or m['rows'][0][2]),('Responsible role',m['role']),('Evidence',m['evidence'])]
  for i,(label,val) in enumerate(pairs[:limit]):
   yy=y+18+i*(78 if mobile else 70)
   self.text(f,x+20,yy,cw-40,label.upper(),11)
   self.text(f,x+20,yy+24,cw-40,val,15,bold=True,h=48)
 @staticmethod
 def field_value(m,label,i):
  t=label.lower()
  if 'password' in t:return '•••••••• · demo only'
  if 'title' in t:return 'Correct a returned household · demonstration'
  if 'purpose' in t:return 'Understand the correction before resubmitting.'
  if t=='steps':return 'Review reason → correct record → resubmit'
  if 'requirements' in t:return 'Current record and authorised staff access'
  if 'next step' in t:return 'Send for independent verification'
  if 'issues' in t:return 'Refresh stale record; retain correction reason'
  if 'visibility' in t:return 'Staff only · matching authorised role'
  if 'date' in t:return '19 Oct 2026 · demonstration'
  if 'audience' in t or 'role' in t:return m['role']
  if 'stage' in t:return 'Correction and independent review'
  if 'service' in t or 'module' in t:return m['name']
  if 'amount' in t:return 'NGN 25,000 · fixture only'
  if 'reference' in t:return m['rows'][0][0]
  if 'state' in t:return 'Kano · demonstration location'
  if 'lga' in t:return 'Dala · demo data'
  if 'reason' in t or 'note' in t:return 'Explain the task-specific reason for review'
  if 'language' in t:return 'English · unapproved sample copy'
  return ('DEMO · '+m['code']+' example') if i==0 else 'Select a demonstration value'
 @staticmethod
 def error_copy(m,s):
  t=s['title'].lower()
  if 'conflict' in t:return 'The saved version differs from this draft. Refresh the original record and compare changes before submitting again.'
  if 'permission' in t or 'denied' in t:return 'This role cannot perform the requested task. Return to a permitted workspace or follow the access request process.'
  if 'duplicate' in t:return 'The reference has already been processed. Inspect the existing record; repeating the request must not create another result.'
  if 'biometric' in t:return 'Mock mismatch. Do not record a successful identity check. Review the approved exception process.'
  if 'source' in t:return 'Keep the last valid aggregate and show its UTC timestamp. A failed source must not be represented as a zero count.'
  return 'Review the required fields and record status. This example does not submit an action or expose real personal data.'
 def module(self,m):
  p=self.page(m['code']+' '+m['name'])
  for i,s in enumerate(m['screens']):
   sm=dict(m);t=s['title'].lower()
   if m['code']=='MBR' and i in [7,8,9,10,11]:sm['role']='Verification officer'
   if m['code']=='HOME':sm['role']=['Assigned staff member','Registration officer','Verification officer','Programme supervisor','Citizen / assisted applicant','Unassigned staff member'][i]
   if m['code']=='KMS' and i in [11,12,13]:sm['role']='Independent knowledge reviewer'
   if m['code']=='KMS' and i in [14,15,17,18,19]:sm['role']='Knowledge publisher / supervisor'
   if m['code']=='CMS' and i in [5,6]:sm['role']='Independent content reviewer'
   if m['code']=='CMS' and i in [7,8,9]:sm['role']='Content publisher'
   if m['code']=='PBMS' and i==11:sm['role']='Conditionality verifier'
   if m['code']=='PBMS' and i in [12,13]:sm['role']='Independent release officer'
   s['role']=sm['role']
   f=self.shell(sm,s,i,p)
   actions=LINKS.get(m['code'],{}).get(i)
   if actions is None:
    if i+1<len(m['screens']):actions=[({'form':'Save and continue','list':'Open selected record','checklist':'Review decision','confirm':'Confirm demonstration','editor':'Save draft','upload':'Validate demo file'}.get(s['kind'],'Continue journey'),i+1)]
    else:actions=[('Return to work queue',0)]
   mobile=m['mobile'];x=18 if mobile else 278;yy=678 if mobile else 900
   resolved=[(label,m['screens'][ix]['id']) for label,ix in actions]
   if not self.name.startswith('NG2P-'):
    cross={('MBR',14):('Open modern registry','NG2P-REG-003'),('PBMS',14):('Open Bridge batch','NG2P-BRG-003'),('BRG',8):('Check account mapping','NG2P-SPAR-002'),('PAR',8):('Open field assignments','NG2P-FLD-001'),('AUTH',5):('Open service catalogue','NG2P-HOME-001'),('PORT',9):('View portal administration','NG2P-PADMIN-003')}
    if (m['code'],i) in cross:resolved.append(cross[(m['code'],i)])
   for j,(label,target) in enumerate(resolved[:3]):
    if mobile:
     by=yy+j*49
     # Only two CTAs fit mobile; a third branch remains available from the index.
     if j>=2:continue
     self.button(f,x,by,label,target,j==0,w=354)
    else:self.button(f,x+j*355,yy,label,target,j==0,w=335)
   if i==0:
    self.flow_refs.append((f,m['code']+' · '+m['name']))
  # A labelled task index exposes every state without requiring hidden gestures.
  idx=self.frame(p,'NG2P-'+m['code']+'-INDEX / Journey map / D1440',x=0,y=((len(m['screens'])+3)//4)*((844 if m['mobile'] else 1040)+140),h=max(1040,250+len(m['screens'])*66))
  self.refs[m['code']+'-INDEX']=idx
  self.text(idx,48,38,1300,m['name']+' · Journey index',34,bold=True)
  self.text(idx,48,101,1280,'Open a named task or state. Buttons inside each screen follow the designed journey. All records and outcomes are fictional.',16)
  for i,s in enumerate(m['screens']):
   self.button(idx,48,170+i*66,s['id']+' · '+s['title'],s['id'],False,w=900)
   self.text(idx,978,181+i*66,400,s['kind'].upper()+' / '+s['viewport'],12)
  self.button(idx,990,40,'All services','START',w=360)
  # Swap every shell's Journey index target from its first task to the real index.
  for n,(ref,target,label) in enumerate(self.links):
   if label=='Journey index' and target==m['screens'][0]['id']:self.links[n]=(ref,m['code']+'-INDEX',label)
 def finish(self):
  for ref,target,label in self.links:
   if target not in self.refs:raise ValueError('Unresolved destination '+target)
   self.add('proto.interaction.add',id=ref,trigger={'type':'onClick'},action={'type':'navigate','dest':self.refs[target]},transition={'type':'dissolve'},durationMs=160)
  for f,name in self.flow_refs:self.add('proto.flow.add',start=f,name=name)
  self.add('page.select',id=1)
  return self.cmd

def write_json(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def run(args,log):
 result=subprocess.run([str(CLI),*map(str,args)],capture_output=True,text=True,encoding='utf-8',errors='replace')
 (ROOT/'qa'/log).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
 if result.returncode:raise RuntimeError(f'{log}: '+result.stdout[-1500:]+result.stderr[-1500:])
 return result

def build(mods,name):
 design=Design(name);design.cover(mods);design.foundations()
 for m in mods:design.module(m)
 commands=design.finish();script=ROOT/'source'/f'{name}.commands.json';write_json(script,commands)
 native=ROOT/'designs'/f'{name}.figcraft';fig=ROOT/'designs'/f'{name}.fig'
 start=time.time();run(['run',script,'--out',native],name+'-build.log')
 run(['export',native,'-o',fig],name+'-fig-export.log')
 run(['convert',native,ROOT/'qa'/f'{name}-native.json'],name+'-native-inspect.log')
 run(['convert',fig,ROOT/'qa'/f'{name}-roundtrip.json'],name+'-fig-reopen.log')
 native_data=json.loads((ROOT/'qa'/f'{name}-native.json').read_text(encoding='utf-8'))
 rt=json.loads((ROOT/'qa'/f'{name}-roundtrip.json').read_text(encoding='utf-8'))
 def counts(data):
  nodes=data['nodes'];return {'nodes':len(nodes),'pages':sum(n['type']=='page' for n in nodes.values()),'frames':sum(n['type']=='frame' for n in nodes.values()),'components':sum(n['type']=='component' for n in nodes.values()),'instances':sum(n['type']=='instance' for n in nodes.values()),'interactions':sum(len(n.get('interactions',[])) for n in nodes.values()),'flows':sum(len(n.get('flows',[])) for n in nodes.values())}
 check={'file':name,'screens':sum(len(m['screens']) for m in mods),'native':counts(native_data),'figcraft_reopen_of_fig':counts(rt),'figma_application_verified':False,'seconds':round(time.time()-start,1)}
 write_json(ROOT/'qa'/f'{name}-validation.json',check)
 print(json.dumps(check),flush=True)
 return check

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--module');parser.add_argument('--master',action='store_true');parser.add_argument('--all',action='store_true');args=parser.parse_args()
 write_json(ROOT/'source'/'screen-specification.json',MODULES)
 validation=[]
 if args.module:
  m=next(m for m in MODULES if m['code']==args.module);validation.append(build([m],'NG2P-'+m['code']+'-'+safe(m['name'])))
 elif args.master:validation.append(build(MODULES,'NigeriaG2P-Master-UX-UI-Prototype'))
 elif args.all:
  for m in MODULES:validation.append(build([m],'NG2P-'+m['code']+'-'+safe(m['name'])))
  validation.append(build(MODULES,'NigeriaG2P-Master-UX-UI-Prototype'))
 write_json(ROOT/'qa'/'latest-build.json',validation)

