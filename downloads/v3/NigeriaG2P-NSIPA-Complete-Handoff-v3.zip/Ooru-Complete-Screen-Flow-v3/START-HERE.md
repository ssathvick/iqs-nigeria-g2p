# Persona screen flow and verified test access

Prepared for Ooru's team · 28 October 2026

## How to use this package

Open `Prototype-Preview.html` in a browser. Select an application area and screen, or use the service map and the **Show clickable areas** control. `Screen-Register.csv` lists all 240 states, their role, reference and caveat. `Interaction-Register.csv` records the design prototype's click destinations. Screen names below are design IDs, not backend routes or verified API contracts. The current editable FigCraft and Figma files are in the companion [v2 design package](../NigeriaG2P-Figma-Design-Package-v2/README.md). Figma import and playback remain unverified.

The videos in `walkthroughs/` narrate design preview images; they are not live screen recordings and do not demonstrate backend transactions. Screens and outcomes labelled proposed must be agreed with Ooru. The deployment kit does not replace native registry or PBMS forms. Test with fictional data only.

## Verified access

Passwords are in the separate private credential document; they are deliberately omitted here. Live sign-in and landing-screen checks were completed on 28 October, not a complete permissions or transaction audit. Individual application availability depends on the running lab.

| Persona or service | Username | Entry point | Verified scope |
|---|---|---|---|
| Registration officer | ooru.demo.registration | https://nigeriag2p.com/registration/login?mode=staff&workspace=1 | Sign-in and officer workspace |
| Verification officer | ooru.demo.verification | same staff workspace link | Sign-in and verifier workspace |
| Programme supervisor | ooru.demo.supervisor | same staff workspace link | Sign-in and supervisor workspace |
| Citizen | ooru.demo.citizen | https://nigeriag2p.com/registration/login?mode=beneficiary&workspace=1 | Citizen workspace and beneficiary self-service sign-in |
| Staff portal | ooru.demo.staffportal | https://staff-portal.nigeriag2p.com | Staff Portal landing screen |
| Staff access administrator | ooru.demo.keycloak | https://iam-staff-ui.nigeriag2p.com | IAM applications screen; staff-realm admin role |
| Configuration administrator persona | ooru.demo.admin | staff workspace link | Identity authenticates but workspace/configuration permissions are not assigned |

The normal staff login can redirect persona users to a reviewer-only page and show 403. Use the workspace links above. Native registry permissions are separate from persona permissions. The service-specific Modern Social Registry login, `ooru.demo.modernregistry`, reaches https://register.nigeriag2p.com; it has broad lab roles and should not be represented as the registration officer's permissions.

## Screen flow for the Social Registry

This sequence answers the meeting's question about what a user should see. It is a review sequence, not a claim that every arrow is wired in the prototype or implemented in the backend.

1. **Sign in and enter role workspace:** AUTH-001/002/007 → HOME-002, 003, 004 or 005. AUTH-004/005 illustrate denied or expired sessions. The workspace or IAM role is assigned by the identity system; changing a prototype tab does not grant access.
2. **Locate records:** REG-001 overview → REG-004 households directory → REG-005 household membership, or REG-002 individuals directory → REG-003 individual profile. REG-008 shows an empty search. Ooru requested that “Open household” and “Open individual” lead to actual lists; confirm whether “open” means all accessible records or a pending queue. The prototype's journey information is not the record list.
3. **Intake:** MBR-017 is an NSR intake prototype. The separate lab household form at `/registration/profile` contains household details and members for fictional records, but it is not the agreed client intake form. Confirm the real individual and household form, fields, validation, ownership and submission API. The design does not prove that a submission reaches the client's registry.
4. **Work on a case:** MBR-001 queue → MBR-002 household overview → MBR-003 members → MBR-004 correction. MBR-005 is validation error, MBR-006 unsaved-change confirmation and MBR-007 submitted state. REG-006/007 illustrate a demographic change request and its status. The exact membership change process remains to be agreed.
5. **Independent review:** MBR-008 checklist → MBR-009/010 return for correction, or MBR-011/012 approval. Approval tasks also have AWE-001 assigned queue → AWE-002 request details → AWE-003 evidence → AWE-004 approve or AWE-005 return. Agree which system owns each step, who can decide, and how a returned case is resubmitted.
6. **After decision:** MBR-013 pending synchronisation → MBR-015 synchronised, with MBR-014 conflict and MBR-016 activity history as alternatives. AWE-006/007/008 show callback pending, delivered or failed. These are reference states, not confirmed integration outcomes.
7. **Downstream programme:** PBMS-004 begins with approved NSR import → PBMS-005 eligibility preview → PBMS-007 list approval → PBMS-008 enrolment → PBMS-009 benefit calculation → PBMS-010 batch review. PBMS-006 and 011–015 show exceptions and conditionality/decision states. Do not describe an intake submission as an automatic programme enrolment or payment.

## Walkthrough by persona

- **Registration officer:** HOME-002 → REG-004/005 or REG-002/003 → MBR-017 intake prototype → MBR-001–007 correction/submission. Explain errors and the distinction between lab and client intake.
- **Verification officer:** HOME-003 → MBR-008–012 or AWE-001–005. Show both approve and return paths; the maker and reviewer should be independent where required. Confirm authority and evidence with Ooru.
- **Programme supervisor:** HOME-004 → ANL-001 and relevant source/freshness states → PBMS-001–015. Explain aggregate information and exceptions without assuming record-level permission.
- **Citizen / assisted applicant:** HOME-005 → PORT-001/002 programme discovery → PORT-005 sign-in → PORT-006/007 dashboard and application → PORT-008–011 prototype form, validation, submission and tracking → PORT-012/013 grievance/help. Direct application is a prototype; it does not establish automatic PBMS integration.
- **Staff access administrator:** IAM-001–007 show accounts, role request, independent approval, confirmation, suspension and history as proposed reference states. The live IAM applications screen has been verified with the separate staff-admin login, but these design actions and exact permissions have not all been verified. The configuration-only `ooru.demo.admin` account is not provisioned with that access.
- **Knowledge editor, reviewer and publisher:** KMS-001–006 library and help; KMS-007–011 draft and save; KMS-012–014 independent review/return; KMS-015–020 publication, history, archive and restore; KMS-021 conflict. These are additional KMS roles, not the five portal persona accounts; the experience kit needs its own configured accounts.

## Decisions required before implementation

Confirm the actual intake forms and APIs; field and evidence requirements; role names and jurisdiction; record list filters and status labels; distinction between review and approval; maker-checker rules; sync ownership and failure handling; and which design-only navigation should appear in production. Agree permissions at both UI and backend layers. The screen and interaction registers cover all 26 application areas, including supporting-service reference screens; they are not a complete inventory of every native upstream interface.

## NSIPA v2 — 3 November 2026

This edition refreshes the visual identity to the NSIPA logo and green/gold palette. Previews and walkthrough images were regenerated from the v2 design sources. Earlier access checks remain dated 28 October 2026; this branding refresh does not renew those checks or change workflow scope. The editable master is in the companion `NigeriaG2P-Figma-Design-Package-v2/designs/` package.
