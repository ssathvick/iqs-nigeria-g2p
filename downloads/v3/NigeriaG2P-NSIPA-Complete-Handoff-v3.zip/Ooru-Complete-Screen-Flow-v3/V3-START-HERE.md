# Nigeria G2P complete screen flow v3

Open `Prototype-Preview.html` for the 273-screen clickable design. Registers list screen IDs and interactions. Editable FigCraft and Figma exports are in the companion design package.

New v3 areas: connected service dashboards, territorial atlas, Jos CCT pilot and Android/iOS sample field collection. Design states are illustrative and use fictional data. The shared offline supervisor PIN is not authentication. The iOS web preview has no server sync. Jos payments are simulated. Public geographic values must identify source, year, level and classification; gaps are retained.

The five walkthrough videos under `walkthroughs/` are historical v2 recordings: they do not depict the new v3 journeys. Prior access evidence remains dated; it was not re-verified by this package.
