# Social Registry handoff for Ooru's team

Working draft · 28 October 2026 · Based on the meeting recording and the supplied release files. Proposed behaviors and permissions need agreement with the Social Registry owner and backend team.

Start with [implementation and screen map](implementation-and-screen-map.md), then use [persona walkthrough](persona-walkthrough.md) to record or demonstrate each role. The [screen register](screen-register.csv) and `previews/` contain existing design references, not a working application. The original release remains at https://github.com/ssathvick/NigeriaG2P_KMS_Analytics_Ver01/releases/tag/v1.0.0-rc1.

## Important boundary

The released deployment kit is an experience launcher, knowledge management and aggregate analytics service beside OpenG2P. Its README explicitly says it does **not** replace native Registry/PBMS forms or deploy the Figma design catalogue. The existing design screens are reference designs and do not establish working API behavior. Figma import and playback remain unverified.

A separate lab source snapshot contains a fictional-data household registration demo. It is not established that this snapshot, its form, or its integration was included in the released public kit. It should be evaluated against Ooru's actual intake process before reuse. No credentials or real beneficiary data are included in this handoff.

## Delivery status

- Existing REG, RADM and AWE preview images and source screen IDs: included for discussion.
- Intake field inventory, operational screen behavior, proposed access matrix, acceptance criteria and questions: included as working specifications.
- Actual client intake form, verified role accounts, endpoint/schema mapping and narrated recordings: **outstanding**, dependent on the actual system and team confirmation. Nothing has been enabled or deployed by this handoff.
- Send test account details separately through the team's agreed secure channel. Do not commit credentials, client data or backups to the public repository.

## NSIPA v2 — 3 November 2026

This edition refreshes the visual identity to the NSIPA logo and green/gold palette. Previews and walkthrough images were regenerated from the v2 design sources. Earlier access checks remain dated 28 October 2026; this branding refresh does not renew those checks or change workflow scope. The editable master is in the companion `NigeriaG2P-Figma-Design-Package-v2/designs/` package.
