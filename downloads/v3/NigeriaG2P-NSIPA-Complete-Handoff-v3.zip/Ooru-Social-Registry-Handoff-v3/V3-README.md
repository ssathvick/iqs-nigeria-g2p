# Registry handoff v3

This area preserves historical registry guidance and adds the v3 dashboard, territory, Jos and field flows in the companion design package. Existing role and access evidence is historical, not revalidated. The supervisor demo PIN is not an authenticated staff identity.
