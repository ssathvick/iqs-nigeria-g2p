# Social Registry implementation and screen map

## Priority and decisions

The 28 October discussion requested intake forms, meaningful household/individual lists, clarity on sidebar and approval flow, and role-based demonstrations. Begin with Social Registry administration and the registry flow; confirm scope with Ooru before using other module designs.

The following is a proposal for discussion, not a statement that the current release already implements it.

| Entry or action | Expected destination or behavior | Existing design reference | Decision |
|---|---|---|---|
| Administration | Configuration navigation, subject to permissions | RADM-001 | Confirm configuration items and role |
| Open households | Searchable, paginated household list, then authorized record detail | REG-004 → REG-005 | Confirm whether “open” means all accessible records or only pending cases; rename to match |
| Open individuals | Searchable, paginated individual list, then authorized profile | REG-002 → REG-003 | Same status and access decision |
| Register or intake | Select household/individual intake, capture fields, validate and submit | Intake form is not identified as a verified standalone REG screen in the released register | Team to provide actual form, fields and ingestion contract |
| Change household membership | Open an authorized household, propose a membership change, show its status | REG-005, REG-006/007 and RADM-003 | Confirm whether membership is its own change type and which screen owns it |
| Review/approve | Assigned task list → details/evidence → approve or return with reason | AWE-001–005 | Confirm roles, distinct review/approval actions and workflow engine |
| Dashboard counts | Aggregate totals and pending counts, if authorized | REG-001, RADM-001 | Confirm visibility and whether counts link to a permitted list |

Journey maps, service maps and persona selectors in the prototype help explain the design. They should not automatically become production navigation or a way to change permissions; decide with the product owner. A desktop sidebar may be used for authorized navigation; the mobile equivalent must be designed and tested. Enforce permissions server-side.

## Intake reference inventory — lab demo only

The separate lab snapshot's `lab/registration-ui/profile.html` and `lab/registration_app.py` contain a beneficiary-mode household demo at `/registration/profile`. The template needs the application, authentication and its configured services; it cannot be run by opening the HTML alone. The route and live site have not been verified for this handoff.

It captures household name, state/FCT, optional LGA and ward, community, monthly income, optional coordinates, and up to eight members (given/family name, date of birth and gender), then asks for a fictional-data confirmation. The server validates member names, date of birth, gender, state and income and puts a submission in `pending_review`. Approved profiles are locked in this demo. This is **not** a production intake specification or a complete individual intake form. LGA coverage is limited to demonstration data. Do not use real records in it.

For the actual intake form agree: applicant and household data dictionary, required/optional fields, validation, identity and deduplication checks, consent, evidence, save/resume, submission identifier, who can submit, review and correction states, and API/ownership. Use the client's actual existing forms and schemas as the source of truth.

## Proposed role matrix — confirm, do not treat as current system permissions

| Capability | Configuration administrator | Registration officer | Verification / approver | Supervisor | Citizen |
|---|---|---|---|---|---|
| Configure system | Yes, within assigned scope | No | No | As assigned | No |
| See identifiable records | No by default | Assigned scope | Assigned tasks/scope | Only if explicitly authorized | Own record if enabled |
| Create or submit intake | No by default | Assigned scope | No by default | No by default | Own application if enabled |
| Review evidence | No by default | As assigned | Assigned tasks | As assigned | Own submission if enabled |
| Approve / return | No by default | No by default | Explicit approval permission | As assigned | No |
| Aggregate counts | If authorized | If authorized | If authorized | If authorized | No |

The meeting stated that configuration admins should not automatically see personal data. Confirm whether the same person can be granted multiple roles, segregation-of-duties rules, jurisdiction, delegated access, and actual identity-provider role names. Existing design labels including RADM “registry administrator” do not prove access rights.

## Backend integration and acceptance

Ooru's team should supply actual endpoints, authentication and role claims, payloads, status values, pagination/filtering, error formats, file access and audit behavior. No endpoint or schema is asserted here. Preserve their current workflow until the mapping is agreed.

Acceptance in a synthetic-data staging environment:

1. An authorized officer opens household and individual lists, searches, opens a detail and sees an appropriate empty/error state; an unauthorized account cannot retrieve records even by direct URL or API.
2. A valid intake is submitted once, receives a traceable identifier and appears in the agreed queue; invalid data gives actionable field errors. Confirm idempotency and duplicate handling.
3. The assigned reviewer can see only authorized evidence; the approver can approve or return according to policy, with a reason where required. The resulting status is consistent across list, detail and task views, including failures and retries.
4. A configuration-only administrator sees only approved aggregate counts and configuration, with no record access unless separately granted. Confirm audit logging and segregation of duties.
5. Test each role and session-expired/access-denied state, desktop/mobile navigation, and actual integration in staging. Record results and unresolved gaps.

## Questions for Ooru

1. Which existing system owns intake, and can you share the current screens, schema, field validations, API contract and permitted test environment?
2. What exactly does “open” mean: all active records, pending review, or another status? Are household and individual lists separate?
3. What are the actual role names, data scopes, approval steps and permissions? Can administrators hold an additional operational role?
4. Who owns membership changes and approval, and are review and approval separate actions?
5. Which sidebar and configuration items are required for the first delivery? Which prototype navigation elements should be removed?

## NSIPA v2 — 3 November 2026

This edition refreshes the visual identity to the NSIPA logo and green/gold palette. Previews and walkthrough images were regenerated from the v2 design sources. Earlier access checks remain dated 28 October 2026; this branding refresh does not renew those checks or change workflow scope. The editable master is in the companion `NigeriaG2P-Figma-Design-Package-v2/designs/` package.
