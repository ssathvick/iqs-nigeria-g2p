# Persona walkthrough and recording script

These are recording scripts, not recordings or verified account instructions. Use synthetic test records and a staging environment. Record the actual user role displayed after sign-in; avoid exposing passwords, tokens, real data or administrative secrets. Confirm roles and actions with Ooru before presenting them as final.

## 1. Configuration administrator

1. Sign in using an approved configuration-only test account. Show the role and administrative sidebar.
2. Walk through available configuration items. Explain that service maps and persona selectors are design aids where applicable.
3. Show permitted aggregate information. Demonstrate that individual and household records are inaccessible unless a separate role is explicitly granted.

## 2. Registration officer

1. Sign in as the registration officer. Open the household directory (REG-004 preview), then a synthetic household and membership (REG-005). Show search, status and the expected empty state (REG-008).
2. Open individuals (REG-002) and an individual profile (REG-003). Explain which actions are allowed.
3. Demonstrate the client's real intake form when available: required fields, validation, submit and the resulting identifier/status. Do not substitute the lab fictional-data template for the client's actual form without agreement.
4. If allowed, demonstrate a change request and its status (REG-006/007); explain how it reaches approval.

## 3. Verification / approval role

1. Sign in as an assigned reviewer/approver. Open the task queue and a synthetic task (AWE-001/002), then the evidence checklist (AWE-003).
2. Explain the difference between review and a decision. Demonstrate approve and return with reason only if the account is authorized (AWE-004/005).
3. Show status in the source record and task. Confirm who can act, failure handling and audit with the backend team.

## 4. Supervisor and citizen, if in scope

Demonstrate only permissions and flows confirmed by the product owner. Supervisor aggregate monitoring and citizen self-service are not established by the preview alone. Record separate clips after test accounts and the actual flows are available.

## Account handoff checklist

For each verified role provide: role name and purpose, environment URL, how a named test user gets access, allowed navigation and actions, data scope, expected denied actions, and the contact for account issues. Supply credentials separately via the agreed secure channel; never put them in this package or repository. The `/registration/profile` lab route requires beneficiary mode and is not confirmed as accessible on the public site.

## Recording completion checklist

- A narrated clip for each agreed persona, with captions if available.
- Screen ID or actual page name, role, action and expected outcome stated aloud.
- Demonstrate list → detail → action → result, including permission and error cases.
- Mark discrepancies between the released design, actual system and proposed behavior for Ooru to resolve.

## NSIPA v2 — 3 November 2026

This edition refreshes the visual identity to the NSIPA logo and green/gold palette. Previews and walkthrough images were regenerated from the v2 design sources. Earlier access checks remain dated 28 October 2026; this branding refresh does not renew those checks or change workflow scope. The editable master is in the companion `NigeriaG2P-Figma-Design-Package-v2/designs/` package.
