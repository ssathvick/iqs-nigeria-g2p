# Nigeria G2P / NSIPA v3 complete handoff

Prepared 4 November 2026.

- `NigeriaG2P-Figma-Design-Package-v3/README.md`: editable master and module files, 273 design states, 31 FigCraft files and 31 `.fig` exports. FigCraft reopen checks pass; direct Figma import and prototype playback have not been verified.
- `Ooru-Complete-Screen-Flow-v3/V3-START-HERE.md`: clickable browser preview, updated registers and historical v2 narrated videos.
- `Ooru-Social-Registry-Handoff-v3/V3-README.md`: historical registry notes with v3 context.
- `OpenG2P-Experience-Kit-v3/README.md`: runnable starter, sample field preview, test Android source and lab UI reference excerpts. External service integrations are not included as working connections.

V3 adds source-led design journeys for service dashboards, separately mapped administrative and electoral geography, the Jos CCT pilot, and sample mobile field work. Designs illustrate states, not live actions. The USD 1.5 million Jos pilot is a demonstration and all payments are simulated. Economic and representative data require source/date/level/classification, with gaps preserved.

The Android app uses fictional data and a hard-coded demo PIN; it does not authenticate a supervisor. The OnePlus offline-to-online sample upload was tested against an isolated ODK project. iPhone/iPad web preview stores a local sample draft only and has no supervisor authentication or server sync. The Experience Kit excludes tokens, beneficiary records and infrastructure secrets.
